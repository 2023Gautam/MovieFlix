package com.cts.developmenttwo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DevelopmentTwoApplicationTests {

	@Test
	void contextLoads() {
	}

}
