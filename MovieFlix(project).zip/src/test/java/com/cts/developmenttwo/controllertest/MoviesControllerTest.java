//package com.cts.developmenttwo.controllertest;
//import static org.mockito.Mockito.when;
//import static org.mockito.ArgumentMatchers.anyString;
//import static org.junit.jupiter.api.Assertions.assertEquals;
//import static org.mockito.ArgumentMatchers.any;
//import static org.mockito.Mockito.doNothing;
//import static org.mockito.Mockito.verify;
//
//import java.util.ArrayList;
//import java.util.List;
//
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;
//import org.mockito.InjectMocks;
//import org.mockito.Mock;
//import org.mockito.MockitoAnnotations;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//
//import com.cts.controller.MoviesController;
//import com.cts.exception.MovieNotFoundException;
//import com.cts.model.Movie;
//import com.cts.pojo.ApiResponce;
//import com.cts.pojo.MovieModel;
//import com.cts.service.MovieService;
//
//class MoviesControllerTest {
//
//  @Mock
//  private MovieService movieService;
//
//  @InjectMocks
//  private MoviesController moviesController;
//
//  @BeforeEach
//  void setUp() {
//    MockitoAnnotations.openMocks(this);
//  }
//
//  @Test
//  void testFindAllMovies() {
//    List<Movie> movies = new ArrayList<>();
//    movies.add(new Movie("1", "Movie 1", "Genre 1", 2023, 9.99, true));
//    movies.add(new Movie("2", "Movie 2", "Genre 2", 2024, 8.99, true));
//
//    when(movieService.findAllMovies()).thenReturn(movies);
//
//    ResponseEntity<List<Movie>> response = moviesController.findAllMovies();
//    assertEquals(HttpStatus.OK, response.getStatusCode());
//    assertEquals(movies, response.getBody());
//    verify(movieService).findAllMovies();
//  }
//  
//  @Test
//  void testFindByMovieId() throws MovieNotFoundException {
//	 String movId ="AB123";
//	 Movie movies = new Movie("AB123", "Movie 1", "Genre 1", 2023, 9.99, true);
//
//    when(movieService.findByMovieId(movId)).thenReturn(movies);
//
//    ResponseEntity<Movie> response = moviesController.findByMovieId(movId);
//    assertEquals(HttpStatus.OK, response.getStatusCode());
//    assertEquals(movies, response.getBody());
//    verify(movieService).findByMovieId(movId);
//  }
//  
//
//  @Test
//  void testAddMovie() {
//    MovieModel movieModel = new MovieModel("1", "Movie 1", "Genre 1", 2023, 9.99);
//    Movie movie = new Movie("1", "Movie 1", "Genre 1", 2023, 9.99, true);
//
//    when(movieService.addMovie(any(Movie.class))).thenReturn(movie);
//
//    ResponseEntity<Movie> response = moviesController.addMovie(movieModel);
//    assertEquals(HttpStatus.OK, response.getStatusCode());
//    assertEquals(movie, response.getBody());
//    verify(movieService).addMovie(any(Movie.class));
//  }
//
//  @Test
//  void testUpdateMovie() throws MovieNotFoundException {
//    MovieModel movieModel = new MovieModel("1", "Movie 1", "Genre 1", 2023, 9.99);
//    Movie updatedMovie = new Movie("1", "Updated Movie", "Genre 1", 2023, 9.99, true);
//
//    when(movieService.findByMovieId("1")).thenReturn(new Movie("1", "Movie 1", "Genre 1", 2023, 9.99, true));
//    when(movieService.addMovie(any(Movie.class))).thenReturn(updatedMovie);
//
//    Movie response = moviesController.updateMovie(movieModel);
//    assertEquals(updatedMovie, response);
//    verify(movieService).findByMovieId("1");
//    verify(movieService).addMovie(any(Movie.class));
//  }
//  
//  @Test
//  void testFindByMovieGenre() throws MovieNotFoundException {
//    List<Movie> movies = new ArrayList<>();
//    movies.add(new Movie("1", "Movie 1", "Genre 1", 2023, 9.99, true));
//    movies.add(new Movie("2", "Movie 2", "Genre 1", 2024, 8.99, true));
//
//    when(movieService.findBymovGenre("Genre 1")).thenReturn(movies);
//
//    ResponseEntity<List<Movie>> response = moviesController.findByMovieGenre("Genre 1");
//    assertEquals(HttpStatus.OK, response.getStatusCode());
//    assertEquals(movies, response.getBody());
//    verify(movieService).findBymovGenre("Genre 1");
//  }
//
//  @Test
//  void testDeleteByMovieId() throws MovieNotFoundException {
//    doNothing().when(movieService).deleteByMovieId("1");
//    ApiResponce api = new ApiResponce();
//    api.setStatus("deleted");
//
//    ResponseEntity<ApiResponce> response = moviesController.deleteByMovieId("1");
//
//    assertEquals(HttpStatus.OK, response.getStatusCode());
//    assertEquals(api, response.getBody());
//    verify(movieService).deleteByMovieId("1");
//  }
//  
//  @Test
//  void testFindByMovieTitle() throws MovieNotFoundException {
//    List<Movie> movies = new ArrayList<>();
//    movies.add(new Movie("1", "Movie 1", "Genre 1", 2023, 9.99, true));
//    movies.add(new Movie("2", "Movie 2", "Genre 1", 2024, 8.99, true));
//
//    when(movieService.findBymovTitle(anyString())).thenReturn(movies);
//
//    ResponseEntity<List<Movie>> response = moviesController.findByMovieTitle("Title");
//    assertEquals(HttpStatus.OK, response.getStatusCode());
//    assertEquals(movies, response.getBody());
//    verify(movieService).findBymovTitle("Title");
//  }
//}

package com.cts.developmenttwo.controllertest;
import static org.mockito.Mockito.when;
import static org.mockito.ArgumentMatchers.anyString;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.verify;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.cts.controller.MoviesController;
import com.cts.exception.MovieNotFoundException;
import com.cts.model.Movie;
import com.cts.pojo.ApiResponce;
import com.cts.pojo.MovieModel;
import com.cts.service.MovieService;

class MoviesControllerTest {

  @Mock
  private MovieService movieService;

  @InjectMocks
  private MoviesController moviesController;

  @BeforeEach
  void setUp() {
    MockitoAnnotations.openMocks(this);
  }

  @Test
  void testFindAllMovies() {
    List<Movie> movies = new ArrayList<>();
    movies.add(new Movie("1", "Movie 1", "Genre 1", 2023, 9.99, true));
    movies.add(new Movie("2", "Movie 2", "Genre 2", 2024, 8.99, true));

    when(movieService.findAllMovies()).thenReturn(movies);

    ResponseEntity<List<Movie>> response = moviesController.findAllMovies();
    assertEquals(HttpStatus.OK, response.getStatusCode());
    assertEquals(movies, response.getBody());
    verify(movieService).findAllMovies();
  }
  
  @Test
  void testFindByMovieId() throws MovieNotFoundException {
	 String movId ="AB123";
	 Movie movies = new Movie("AB123", "Movie 1", "Genre 1", 2023, 9.99, true);

    when(movieService.findByMovieId(movId)).thenReturn(movies);

    ResponseEntity<Movie> response = moviesController.findByMovieId(movId);
    assertEquals(HttpStatus.OK, response.getStatusCode());
    assertEquals(movies, response.getBody());
    verify(movieService).findByMovieId(movId);
  }
  

  @Test
  void testAddMovie() {
    MovieModel movieModel = new MovieModel("1", "Movie 1", "Genre 1", 2023, 9.99);
    Movie movie = new Movie("1", "Movie 1", "Genre 1", 2023, 9.99, true);

    when(movieService.addMovie(any(Movie.class))).thenReturn(movie);

    ResponseEntity<Movie> response = moviesController.addMovie(movieModel);
    assertEquals(HttpStatus.OK, response.getStatusCode());
    assertEquals(movie, response.getBody());
    verify(movieService).addMovie(any(Movie.class));
  }

  @Test
  void testUpdateMovie() throws MovieNotFoundException {
    MovieModel movieModel = new MovieModel("1", "Movie 1", "Genre 1", 2023, 9.99);
    Movie updatedMovie = new Movie("1", "Updated Movie", "Genre 1", 2023, 9.99, true);

    when(movieService.findByMovieId("1")).thenReturn(new Movie("1", "Movie 1", "Genre 1", 2023, 9.99, true));
    when(movieService.addMovie(any(Movie.class))).thenReturn(updatedMovie);

    Movie response = moviesController.updateMovie(movieModel);
    assertEquals(updatedMovie, response);
    verify(movieService).findByMovieId("1");
    verify(movieService).addMovie(any(Movie.class));
  }
  
  @Test
  void testFindByMovieGenre() throws MovieNotFoundException {
    List<Movie> movies = new ArrayList<>();
    movies.add(new Movie("1", "Movie 1", "Genre 1", 2023, 9.99, true));
    movies.add(new Movie("2", "Movie 2", "Genre 1", 2024, 8.99, true));

    when(movieService.findBymovGenre("Genre 1")).thenReturn(movies);

    ResponseEntity<List<Movie>> response = moviesController.findByMovieGenre("Genre 1");
    assertEquals(HttpStatus.OK, response.getStatusCode());
    assertEquals(movies, response.getBody());
    verify(movieService).findBymovGenre("Genre 1");
  }

  @Test
  void testDeleteByMovieId() throws MovieNotFoundException {
    doNothing().when(movieService).deleteByMovieId("1");
    ApiResponce api = new ApiResponce();
    api.setStatus("deleted");

    ResponseEntity<ApiResponce> response = moviesController.deleteByMovieId("1");

    assertEquals(HttpStatus.OK, response.getStatusCode());
    assertEquals(api, response.getBody());
    verify(movieService).deleteByMovieId("1");
  }
  
  @Test
  void testFindByMovieTitle() throws MovieNotFoundException {
    List<Movie> movies = new ArrayList<>();
    movies.add(new Movie("1", "Movie 1", "Genre 1", 2023, 9.99, true));
    movies.add(new Movie("2", "Movie 2", "Genre 1", 2024, 8.99, true));

    when(movieService.findBymovTitle(anyString())).thenReturn(movies);

    ResponseEntity<List<Movie>> response = moviesController.findByMovieTitle("Title");
    assertEquals(HttpStatus.OK, response.getStatusCode());
    assertEquals(movies, response.getBody());
    verify(movieService).findBymovTitle("Title");
  }
}

