//package com.cts.developmenttwo.controllertest;
//
//import static org.mockito.ArgumentMatchers.any;
//import static org.mockito.Mockito.times;
//import static org.mockito.Mockito.verify;
//import static org.mockito.Mockito.when;
//import static org.junit.jupiter.api.Assertions.assertEquals;
//
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;
//import org.mockito.InjectMocks;
//import org.mockito.Mock;
//import org.mockito.MockitoAnnotations;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//
//import com.cts.controller.UsersController;
//import com.cts.dao.UsersRepository;
//import com.cts.exception.UserNotFoundException;
//import com.cts.model.Users;
//import com.cts.pojo.ApiResponce;
//import com.cts.pojo.UsersModel;
//import com.cts.service.UsersService;
//
//class UsersControllerTest {
//
//  @Mock
//  private UsersService usersService;
//  
//  @Mock
//  private UsersRepository usersRepo;
//  
//
//  @InjectMocks
//  private UsersController usersController;
//
//  @BeforeEach
//  void setUp() {
//    MockitoAnnotations.openMocks(this);
//  }
//
//  @Test
//  void testAddCust() throws UserNotFoundException {
//    UsersModel usersModel = new UsersModel("John", "john@example.com", "password");
//    Users addedCustomer = new Users("admin@example.com","UserName","password","category");
//
//    when(usersService.addCust(any(UsersModel.class))).thenReturn(addedCustomer);
//
//    ResponseEntity<Users> response = usersController.addCust(usersModel);
//    assertEquals(HttpStatus.OK, response.getStatusCode());
//    assertEquals(addedCustomer, response.getBody());
//    verify(usersService).addCust(any(UsersModel.class));
//  }
//  
//  @Test
//  void testFindByUserId() throws UserNotFoundException {
//	  String emailId="test@gmail.com";
//	  Users user = new Users("admin@example.com","UserName","password","category");
//	  
//	  when(usersRepo.findById(emailId)).thenReturn(java.util.Optional.of(user));
//	  Users user2 = usersService.findByUserId(emailId);
////	  verify(usersRepo).findById(emailId);
//	  assertEquals(user, user2);
//  }
//
//  @Test
//  void testUsersLogin() throws UserNotFoundException {
//    UsersModel usersModel = new UsersModel("UserName","admin@example.com", "password");
//    Users loggedInUser = new Users("admin@example.com","UserName","password","category");
//    
//    ApiResponce api = new ApiResponce();
//    api.setStatus("Welcome! UserName");
//
//    when(usersService.customerLogin(any(String.class), any(String.class))).thenReturn(loggedInUser);
//
//    ResponseEntity<ApiResponce> response = usersController.usersLogin(usersModel);
//    assertEquals(HttpStatus.OK, response.getStatusCode());
//    assertEquals(api, response.getBody());
//    verify(usersService).customerLogin(any(String.class), any(String.class));
//  }
//
//  
//  @Test
//  void testAdminLogin() throws UserNotFoundException {
//    UsersModel usersModel = new UsersModel("Admin","admin@example.com", "password");
//    Users loggedInUser = new Users("admin@example.com","Admin","password","category");
//    
//    ApiResponce api = new ApiResponce();
//    api.setStatus("Welcome! Admin");
//
//    when(usersService.adminsLogin(any(String.class), any(String.class))).thenReturn(loggedInUser);
//
//    ResponseEntity<ApiResponce> response = usersController.adminLogin(usersModel);
//    assertEquals(HttpStatus.OK, response.getStatusCode());
//    assertEquals( api, response.getBody());
//    verify(usersService).adminsLogin(any(String.class), any(String.class));
//  }
//}

package com.cts.developmenttwo.controllertest;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.cts.controller.UsersController;
import com.cts.dao.UsersRepository;
import com.cts.exception.UserNotFoundException;
import com.cts.model.Users;
import com.cts.pojo.ApiResponce;
import com.cts.pojo.UsersModel;
import com.cts.service.UsersService;

class UsersControllerTest {

  @Mock
  private UsersService usersService;
  
  @Mock
  private UsersRepository usersRepo;
  

  @InjectMocks
  private UsersController usersController;

  @BeforeEach
  void setUp() {
    MockitoAnnotations.openMocks(this);
  }

  @Test
  void testAddCust() throws UserNotFoundException {
    UsersModel usersModel = new UsersModel("John", "john@example.com", "password");
    Users addedCustomer = new Users("admin@example.com","UserName","password","category");

    when(usersService.addCust(any(UsersModel.class))).thenReturn(addedCustomer);

    ResponseEntity<Users> response = usersController.addCust(usersModel);
    assertEquals(HttpStatus.OK, response.getStatusCode());
    assertEquals(addedCustomer, response.getBody());
    verify(usersService).addCust(any(UsersModel.class));
  }
  
  void testFindByUserId() throws UserNotFoundException {
      // Arrange
      String emailId = "admin@example.com";
      Users user = new Users("admin@example.com", "UserName", "password", "category");
      when(usersService.findByUserId(emailId)).thenReturn(user);

      ResponseEntity<Users> response = usersController.findByUserId(emailId);

      assertEquals(HttpStatus.OK, response.getStatusCode());
      assertEquals(user, response.getBody());
      verify(usersService, times(1)).findByUserId(emailId);
  }

  @Test
  void testUsersLogin() throws UserNotFoundException {
    UsersModel usersModel = new UsersModel("UserName","admin@example.com", "password");
    Users loggedInUser = new Users("admin@example.com","UserName","password","category");
    
    ApiResponce api = new ApiResponce();
    api.setStatus("Welcome! UserName");

    when(usersService.customerLogin(any(String.class), any(String.class))).thenReturn(loggedInUser);

    ResponseEntity<ApiResponce> response = usersController.usersLogin(usersModel);
    assertEquals(HttpStatus.OK, response.getStatusCode());
    assertEquals(api, response.getBody());
    verify(usersService).customerLogin(any(String.class), any(String.class));
  }

  
  @Test
  void testAdminLogin() throws UserNotFoundException {
    UsersModel usersModel = new UsersModel("Admin","admin@example.com", "password");
    Users loggedInUser = new Users("admin@example.com","Admin","password","category");
    
    ApiResponce api = new ApiResponce();
    api.setStatus("Welcome! Admin");

    when(usersService.adminsLogin(any(String.class), any(String.class))).thenReturn(loggedInUser);

    ResponseEntity<ApiResponce> response = usersController.adminLogin(usersModel);
    assertEquals(HttpStatus.OK, response.getStatusCode());
    assertEquals( api, response.getBody());
    verify(usersService).adminsLogin(any(String.class), any(String.class));
  }
  
  @Test
  void testFindByUserId_ExistingUser() throws UserNotFoundException {

      String emailId = "user@example.com";
      Users user = new Users(); // Create a sample user
      when(usersService.findByUserId(emailId)).thenReturn(user);


      ResponseEntity<Users> response = usersController.findByUserId(emailId);

      assertEquals(HttpStatus.OK, response.getStatusCode());
      assertEquals(user, response.getBody());
      verify(usersService, times(1)).findByUserId(emailId);
  }

  @Test
  void testFindByUserId_UserNotFoundException() throws UserNotFoundException {

      String emailId = "user@example.com";
      when(usersService.findByUserId(emailId)).thenThrow(new UserNotFoundException("User not found"));

      try {
          usersController.findByUserId(emailId);
      } catch (UserNotFoundException ex) {

          assertEquals("User not found", ex.getMessage());
      }
  }
}


