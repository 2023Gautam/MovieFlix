//package com.cts.developmenttwo.controllertest;
//
//import static org.junit.jupiter.api.Assertions.assertEquals;
//import static org.junit.jupiter.api.Assertions.assertThrows;
//import static org.mockito.ArgumentMatchers.any;
//import static org.mockito.Mockito.verify;
//import static org.mockito.Mockito.when;
//
//import org.aspectj.lang.annotation.Before;
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;
//import org.mockito.InjectMocks;
//import org.mockito.Mock;
//import org.mockito.MockitoAnnotations;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//
//import java.util.ArrayList;
//import java.util.List;
//
//import com.cts.controller.OrdersController;
//import com.cts.exception.MovieNotFoundException;
//import com.cts.exception.OrderNotFoundException;
//import com.cts.exception.UserNotFoundException;
//import com.cts.service.OrdersService;
//import com.cts.pojo.ApiResponce;
//import com.cts.pojo.OrderModel;
//import com.cts.model.Orders;
//
//public class OrdersControllerTest {
//	
//	@Mock
//	private OrdersService ordersService;
//	
//	@InjectMocks
//	private OrdersController ordersController;
//
//	@BeforeEach
//
//    public void setUp() {
//        MockitoAnnotations.initMocks(this);
//    }
//	
//	 @Test
//	  void testPlaceOrder() throws UserNotFoundException, MovieNotFoundException {
//	    OrderModel orderModel = new OrderModel();
//	    Orders placeOrder = new Orders();
//
//	    when(ordersService.placeOrder(any(OrderModel.class))).thenReturn(placeOrder);
//	    ResponseEntity<Orders> response = ordersController.placeOrder(orderModel);
//
//	    assertEquals(HttpStatus.OK, response.getStatusCode());
//	    assertEquals(placeOrder, response.getBody());
//
//	    verify(ordersService).placeOrder(any(OrderModel.class));
//	  }
//
//	  @Test
//	  void testDeleteOrderById() throws OrderNotFoundException {
//	    int orderId = 1;
//	    ApiResponce api = new ApiResponce();
//	    api.setStatus("deleted");
//
//	    ResponseEntity<ApiResponce> response = ordersController.deleteOrderById(orderId);
//
//	    assertEquals(HttpStatus.OK, response.getStatusCode());
//	    assertEquals(api, response.getBody());
//
//	    verify(ordersService).deleteOrderById(orderId);
//	  }
//
//	 
//
//	@Test
//	  void testFindOrdersByUserId() throws OrderNotFoundException, UserNotFoundException {
//	    String emailId = "user@example.com";
//	    List<Orders> ordersList = new ArrayList<>();
//	    Orders order1 = new Orders();
//	    order1.setOrderId(1);
//	    ordersList.add(order1);
//	    
//	    when(ordersService.findOrdersByUserId(emailId)).thenReturn(ordersList);
//
//	    ResponseEntity<List<Orders>> response = ordersController.findOrdersByUserId(emailId);
//
//	    assertEquals(HttpStatus.OK, response.getStatusCode());
//	    assertEquals(ordersList, response.getBody());
//
//	    verify(ordersService).findOrdersByUserId(emailId);
//	  }
//
//	  @Test
//	  void testFindOrdersByUserId_OrderNotFoundException() throws OrderNotFoundException, UserNotFoundException {
//	    String emailId = "user@example.com";
//
//	    when(ordersService.findOrdersByUserId(emailId)).thenThrow(OrderNotFoundException.class);
//
//	    assertThrows(OrderNotFoundException.class, () -> {
//	      ordersController.findOrdersByUserId(emailId);
//	    });
//
//	    verify(ordersService).findOrdersByUserId(emailId);
//	  }
//
//	  @Test
//	  void testFindOrdersByUserId_UserNotFoundException() throws OrderNotFoundException, UserNotFoundException {
//	    String emailId = "user@example.com";
//
//	    when(ordersService.findOrdersByUserId(emailId)).thenThrow(UserNotFoundException.class);
//
//	    assertThrows(UserNotFoundException.class, () -> {
//	      ordersController.findOrdersByUserId(emailId);
//	    });
//
//	    verify(ordersService).findOrdersByUserId(emailId);
//	  }
//}
package com.cts.developmenttwo.controllertest;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.aspectj.lang.annotation.Before;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.ArrayList;
import java.util.List;

import com.cts.controller.OrdersController;
import com.cts.exception.MovieNotFoundException;
import com.cts.exception.OrderNotFoundException;
import com.cts.exception.UserNotFoundException;
import com.cts.service.OrdersService;
import com.cts.pojo.ApiResponce;
import com.cts.pojo.ApprovalModel;
import com.cts.pojo.OrderModel;
import com.cts.model.Orders;

public class OrdersControllerTest {

	@Mock
	private OrdersService ordersService;

	@InjectMocks
	private OrdersController ordersController;

	@BeforeEach

	public void setUp() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	void testPlaceOrder() throws UserNotFoundException, MovieNotFoundException {
		OrderModel orderModel = new OrderModel();
		Orders placeOrder = new Orders();

		when(ordersService.placeOrder(any(OrderModel.class))).thenReturn(placeOrder);
		ResponseEntity<Orders> response = ordersController.placeOrder(orderModel);

		assertEquals(HttpStatus.OK, response.getStatusCode());
		assertEquals(placeOrder, response.getBody());

		verify(ordersService).placeOrder(any(OrderModel.class));
	}

	@Test
	void testDeleteOrderById() throws OrderNotFoundException {
		int orderId = 1;
		ApiResponce api = new ApiResponce();
		api.setStatus("deleted");

		ResponseEntity<ApiResponce> response = ordersController.deleteOrderById(orderId);

		assertEquals(HttpStatus.OK, response.getStatusCode());
		assertEquals(api, response.getBody());

		verify(ordersService).deleteOrderById(orderId);
	}

	@Test
	void testFindOrdersByUserId() throws OrderNotFoundException, UserNotFoundException {
		String emailId = "user@example.com";
		List<Orders> ordersList = new ArrayList<>();
		Orders order1 = new Orders();
		order1.setOrderId(1);
		ordersList.add(order1);

		when(ordersService.findOrdersByUserId(emailId)).thenReturn(ordersList);

		ResponseEntity<List<Orders>> response = ordersController.findOrdersByUserId(emailId);

		assertEquals(HttpStatus.OK, response.getStatusCode());
		assertEquals(ordersList, response.getBody());

		verify(ordersService).findOrdersByUserId(emailId);
	}

	@Test
	void testFindOrdersByUserId_OrderNotFoundException() throws OrderNotFoundException, UserNotFoundException {
		String emailId = "user@example.com";

		when(ordersService.findOrdersByUserId(emailId)).thenThrow(OrderNotFoundException.class);

		assertThrows(OrderNotFoundException.class, () -> {
			ordersController.findOrdersByUserId(emailId);
		});

		verify(ordersService).findOrdersByUserId(emailId);
	}

	@Test
	void testFindOrdersByUserId_UserNotFoundException() throws OrderNotFoundException, UserNotFoundException {
		String emailId = "user@example.com";

		when(ordersService.findOrdersByUserId(emailId)).thenThrow(UserNotFoundException.class);

		assertThrows(UserNotFoundException.class, () -> {
			ordersController.findOrdersByUserId(emailId);
		});

		verify(ordersService).findOrdersByUserId(emailId);
	}

	@Test
	void testApproval_SuccessfulApproval() throws OrderNotFoundException {

		int orderId = 1;
		boolean status = true;
		ApprovalModel approvalModel = new ApprovalModel(orderId, status);
		Orders approvedOrder = new Orders(); // Create a sample approved order
		when(ordersService.approval(orderId, status)).thenReturn(approvedOrder);

		ResponseEntity<Orders> response = ordersController.approval(approvalModel);

		assertEquals(HttpStatus.OK, response.getStatusCode());
		assertEquals(approvedOrder, response.getBody());
		verify(ordersService, times(1)).approval(orderId, status);
	}

	@Test
	void testApproval_OrderNotFoundException() throws OrderNotFoundException {

		int orderId = 1;
		boolean status = true;
		ApprovalModel approvalModel = new ApprovalModel(orderId, status);
		when(ordersService.approval(orderId, status)).thenThrow(new OrderNotFoundException("Order not found"));

		try {
			ordersController.approval(approvalModel);
		} catch (OrderNotFoundException ex) {
			// Assert
			assertEquals("Order not found", ex.getMessage());
		}
	}

	@Test
	void testFindOrdersByOrderId_ExistingOrder() throws OrderNotFoundException, UserNotFoundException {

		int orderId = 1;
		Orders order = new Orders(); // Create a sample order
		when(ordersService.FindOrderById(orderId)).thenReturn(order);

		ResponseEntity<Orders> response = ordersController.findOrdersByOrderId(orderId);

		assertEquals(HttpStatus.OK, response.getStatusCode());
		assertEquals(order, response.getBody());
		verify(ordersService, times(1)).FindOrderById(orderId);
	}

	@Test
	void testFindOrdersByOrderId_OrderNotFoundException() throws OrderNotFoundException, UserNotFoundException {

		int orderId = 1;
		when(ordersService.FindOrderById(orderId)).thenThrow(new OrderNotFoundException("Order not found"));

		try {
			ordersController.findOrdersByOrderId(orderId);
		} catch (OrderNotFoundException ex) {
			// Assert
			assertEquals("Order not found", ex.getMessage());
		}
	}

	@Test
	void testFindAllOrders_ExistingOrders() {

		List<Orders> ordersList = new ArrayList<>();
		ordersList.add(new Orders()); // Add sample orders to the list
		when(ordersService.findAllOrders()).thenReturn(ordersList);

		ResponseEntity<List<Orders>> response = ordersController.findAllOrders();

		assertEquals(HttpStatus.OK, response.getStatusCode());
		assertEquals(ordersList, response.getBody());
		verify(ordersService, times(1)).findAllOrders();
	}

	@Test
	void testFindAllOrders_EmptyOrderList() {

		List<Orders> ordersList = new ArrayList<>();
		when(ordersService.findAllOrders()).thenReturn(ordersList);

		ResponseEntity<List<Orders>> response = ordersController.findAllOrders();

		assertEquals(HttpStatus.OK, response.getStatusCode());
		assertEquals(ordersList, response.getBody());
		verify(ordersService, times(1)).findAllOrders();
	}
}