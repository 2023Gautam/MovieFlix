//package com.cts.developmenttwo.servicetest;
//
//import static org.assertj.core.api.Assertions.assertThatNullPointerException;
//import static org.junit.jupiter.api.Assertions.assertEquals;
//import static org.junit.jupiter.api.Assertions.assertNull;
//import static org.junit.jupiter.api.Assertions.assertThrows;
//import static org.mockito.ArgumentMatchers.any;
//import static org.mockito.Mockito.never;
//import static org.mockito.Mockito.times;
//import static org.mockito.Mockito.verify;
//import static org.mockito.Mockito.when;
//
//import java.util.ArrayList;
//import java.util.List;
//import java.util.Optional;
//
//import org.assertj.core.api.Assertions;
//import org.junit.jupiter.api.Test;
//import org.junit.jupiter.api.extension.ExtendWith;
//import org.mockito.InjectMocks;
//import org.mockito.Mock;
//import org.springframework.test.context.junit.jupiter.SpringExtension;
//
//import com.cts.dao.MovieRepository;
//import com.cts.exception.MovieNotFoundException;
//import com.cts.model.Movie;
//import com.cts.service.MovieServiceImpl;
//
//@ExtendWith(SpringExtension.class)
//public class MovieServiceTest {
//	
//	@Mock
//	MovieRepository movieRepository;
//	
//	@InjectMocks
//	MovieServiceImpl movieServiceImpl;
//	
//	@Test
//	public void addMovieTest() {
//		Movie movie = new Movie();
//		movie.setMovId("RR132");
//		movie.setMovTitle("Rush Hour");
//		movie.setMovGenre("Comedy");
//		movie.setMovYear(2000);
//		movie.setPrice(80.0);
//		
//		when(movieRepository.save(any(Movie.class))).thenReturn(movie);
//		
//		Movie result = movieServiceImpl.addMovie(movie);
//		assertEquals(movie.getMovId(), result.getMovId());
//		assertEquals(movie.getMovTitle(), result.getMovTitle());
//		assertEquals(movie.getMovGenre(), result.getMovGenre());
//		assertEquals(movie.getMovYear(), result.getMovYear());
//		assertEquals(movie.getPrice(), result.getPrice());
//		verify(movieRepository).save(any(Movie.class));
//		
//	}
//	
//	@Test
//	public void findByMovieIdTest() throws MovieNotFoundException {
//		Movie movie = new Movie();
//		movie.setMovId("RR132");
//		movie.setMovTitle("Rush Hour");
//		movie.setMovGenre("Comedy");
//		movie.setMovYear(2000);
//		movie.setPrice(80.0);
//		
//		when(movieRepository.findById("RR132")).thenReturn(Optional.of(movie));
//		
//		Movie result = movieServiceImpl.findByMovieId("RR132");
//		assertEquals(movie.getMovId(), result.getMovId());
//		assertEquals(movie.getMovTitle(), result.getMovTitle());
//		assertEquals(movie.getMovGenre(), result.getMovGenre());
//		assertEquals(movie.getMovYear(), result.getMovYear());
//		assertEquals(movie.getPrice(), result.getPrice()); 
//		verify(movieRepository).findById("RR132");
//	}
//	
//	@Test
//	public void findByMovieTitleTest() throws MovieNotFoundException {
//		Movie movie = new Movie();
//		movie.setMovId("RR132");
//		movie.setMovTitle("Rush Hour");
//		movie.setMovGenre("Comedy");
//		movie.setMovYear(2000);
//		movie.setPrice(80.0);
//		List<Movie> mlt = new ArrayList<>();
//		mlt.add(movie);
//		
//		when(movieRepository.findBymovTitle("Rush Hour")).thenReturn(mlt);
//		
//		List<Movie> result = movieServiceImpl.findBymovTitle("Rush Hour");
//		assertEquals(mlt,result);
//		verify(movieRepository).findBymovTitle("Rush Hour");
//	}
//	
//	@Test
//	public void findByMovieGenreTest() throws MovieNotFoundException {
//		Movie movie = new Movie();
//		movie.setMovId("RR132");
//		movie.setMovTitle("Rush Hour");
//		movie.setMovGenre("Comedy");
//		movie.setMovYear(2000);
//		movie.setPrice(80.0);
//		List<Movie> mlt = new ArrayList<>();
//		mlt.add(movie);
//		
//		when(movieRepository.findBymovGenre("Comedy")).thenReturn(mlt);
//		
//		List<Movie> result = movieServiceImpl.findBymovGenre("Comedy");
//		assertEquals(mlt,result);
//		verify(movieRepository).findBymovGenre("Comedy");
//	}
//	
//	@Test
//	public void findAllMoviesTest(){
//		Movie movie = new Movie();
//		movie.setMovId("RR132");
//		movie.setMovTitle("Rush Hour");
//		movie.setMovGenre("Comedy");
//		movie.setMovYear(2000);
//		movie.setPrice(80.0);
//		movie.setAvail(true);
//		List<Movie> mlt = new ArrayList<>();
//		mlt.add(movie);
//		
//		when(movieRepository.findByAvail()).thenReturn(mlt);
//		
//		List<Movie> result = movieServiceImpl.findAllMovies();
//		assertEquals(mlt,result);
//		verify(movieRepository).findByAvail();
//	}
//	
//	@Test
//	  public void testfindMovByIdIncorrectId() throws MovieNotFoundException {
//		String MovId = "RR132"; 
//		MovieNotFoundException ex = assertThrows(MovieNotFoundException.class, ()->{
//	  		when(movieRepository.findById(MovId)).thenReturn(Optional.empty());
//	  		movieServiceImpl.findByMovieId(MovId);
//	        });
//	        assertEquals("Movie not found...",ex.getMessage());
//	        verify(movieRepository).findById(MovId);
//	  }
//	
//	@Test
//	  public void testfindMovByGenreIncorrectId() throws MovieNotFoundException {
//		String MovGenre = "Comedy";  
//		MovieNotFoundException ex = assertThrows(MovieNotFoundException.class, ()->{
//	    	List<Movie> mlt = new ArrayList<>();
//	  		when(movieRepository.findBymovGenre(MovGenre)).thenReturn(mlt);
//	  		movieServiceImpl.findBymovGenre(MovGenre);
//	        });
//	        assertEquals("Movie not found...",ex.getMessage());
//	        verify(movieRepository).findBymovGenre(MovGenre);
//	  }
//	
//	@Test
//	  public void testfindMovByTitleIncorrectId() throws MovieNotFoundException {
//		String MovTitle = "Rush Hour";
//	      MovieNotFoundException ex = assertThrows(MovieNotFoundException.class, ()->{
//	    	List<Movie> mlt = new ArrayList<>();
//	  		when(movieRepository.findBymovTitle(MovTitle)).thenReturn(mlt);
//	  		movieServiceImpl.findBymovTitle(MovTitle);
//	        });
//	        assertEquals("Movie not found...",ex.getMessage());
//	        verify(movieRepository).findBymovTitle(MovTitle);
//	  }
//	
//	 @Test
//	    public void testDeleteByMovieId_ExistingMovie() throws MovieNotFoundException {
//	        String movieId = "RR123";
//	        Movie movie = new Movie();
//	        when(movieRepository.findById(movieId)).thenReturn(Optional.of(movie));
//
//	        movieServiceImpl.deleteByMovieId(movieId);
////	        verify(movieRepository, times(1)).deleteById(movieId);
//	    }
//
//	    @Test
//	    public void testDeleteByMovieId_NonExistingMovie() {
//	        String movieId = "RR123";
//	        when(movieRepository.findById(movieId)).thenReturn(Optional.empty());
//	        
//	        assertThrows(MovieNotFoundException.class, () -> movieServiceImpl.deleteByMovieId(movieId));
//	        verify(movieRepository, never()).deleteById(movieId);
//	    }
//	
//	
//	
//
//}

package com.cts.developmenttwo.servicetest;

import static org.assertj.core.api.Assertions.assertThatNullPointerException;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.cts.dao.MovieRepository;
import com.cts.exception.MovieNotFoundException;
import com.cts.model.Movie;
import com.cts.service.MovieServiceImpl;

@ExtendWith(SpringExtension.class)
public class MovieServiceTest {
	
	@Mock
	MovieRepository movieRepository;
	
	@InjectMocks
	MovieServiceImpl movieServiceImpl;
	
	@Test
	public void addMovieTest() {
		Movie movie = new Movie();
		movie.setMovId("RR132");
		movie.setMovTitle("Rush Hour");
		movie.setMovGenre("Comedy");
		movie.setMovYear(2000);
		movie.setPrice(80.0);
		
		when(movieRepository.save(any(Movie.class))).thenReturn(movie);
		
		Movie result = movieServiceImpl.addMovie(movie);
		assertEquals(movie.getMovId(), result.getMovId());
		assertEquals(movie.getMovTitle(), result.getMovTitle());
		assertEquals(movie.getMovGenre(), result.getMovGenre());
		assertEquals(movie.getMovYear(), result.getMovYear());
		assertEquals(movie.getPrice(), result.getPrice());
		verify(movieRepository).save(any(Movie.class));
		
	}
	
	@Test
	public void findByMovieIdTest() throws MovieNotFoundException {
		Movie movie = new Movie();
		movie.setMovId("RR132");
		movie.setMovTitle("Rush Hour");
		movie.setMovGenre("Comedy");
		movie.setMovYear(2000);
		movie.setPrice(80.0);
		
		when(movieRepository.findById("RR132")).thenReturn(Optional.of(movie));
		
		Movie result = movieServiceImpl.findByMovieId("RR132");
		assertEquals(movie.getMovId(), result.getMovId());
		assertEquals(movie.getMovTitle(), result.getMovTitle());
		assertEquals(movie.getMovGenre(), result.getMovGenre());
		assertEquals(movie.getMovYear(), result.getMovYear());
		assertEquals(movie.getPrice(), result.getPrice()); 
		verify(movieRepository).findById("RR132");
	}
	
	@Test
	public void findByMovieTitleTest() throws MovieNotFoundException {
		Movie movie = new Movie();
		movie.setMovId("RR132");
		movie.setMovTitle("Rush Hour");
		movie.setMovGenre("Comedy");
		movie.setMovYear(2000);
		movie.setPrice(80.0);
		List<Movie> mlt = new ArrayList<>();
		mlt.add(movie);
		
		when(movieRepository.findBymovTitle("Rush Hour")).thenReturn(mlt);
		
		List<Movie> result = movieServiceImpl.findBymovTitle("Rush Hour");
		assertEquals(mlt,result);
		verify(movieRepository).findBymovTitle("Rush Hour");
	}
	
	@Test
	public void findByMovieGenreTest() throws MovieNotFoundException {
		Movie movie = new Movie();
		movie.setMovId("RR132");
		movie.setMovTitle("Rush Hour");
		movie.setMovGenre("Comedy");
		movie.setMovYear(2000);
		movie.setPrice(80.0);
		List<Movie> mlt = new ArrayList<>();
		mlt.add(movie);
		
		when(movieRepository.findBymovGenre("Comedy")).thenReturn(mlt);
		
		List<Movie> result = movieServiceImpl.findBymovGenre("Comedy");
		assertEquals(mlt,result);
		verify(movieRepository).findBymovGenre("Comedy");
	}
	
	@Test
	public void findAllMoviesTest(){
		Movie movie = new Movie();
		movie.setMovId("RR132");
		movie.setMovTitle("Rush Hour");
		movie.setMovGenre("Comedy");
		movie.setMovYear(2000);
		movie.setPrice(80.0);
		movie.setAvail(true);
		List<Movie> mlt = new ArrayList<>();
		mlt.add(movie);
		
		when(movieRepository.findByAvail()).thenReturn(mlt);
		
		List<Movie> result = movieServiceImpl.findAllMovies();
		assertEquals(mlt,result);
		verify(movieRepository).findByAvail();
	}
	
	@Test
	  public void testfindMovByIdIncorrectId() throws MovieNotFoundException {
		String MovId = "RR132"; 
		MovieNotFoundException ex = assertThrows(MovieNotFoundException.class, ()->{
	  		when(movieRepository.findById(MovId)).thenReturn(Optional.empty());
	  		movieServiceImpl.findByMovieId(MovId);
	        });
	        assertEquals("Movie not found...",ex.getMessage());
	        verify(movieRepository).findById(MovId);
	  }
	
	@Test
	  public void testfindMovByGenreIncorrectId() throws MovieNotFoundException {
		String MovGenre = "Comedy";  
		MovieNotFoundException ex = assertThrows(MovieNotFoundException.class, ()->{
	    	List<Movie> mlt = new ArrayList<>();
	  		when(movieRepository.findBymovGenre(MovGenre)).thenReturn(mlt);
	  		movieServiceImpl.findBymovGenre(MovGenre);
	        });
	        assertEquals("Movie not found...",ex.getMessage());
	        verify(movieRepository).findBymovGenre(MovGenre);
	  }
	
	@Test
	  public void testfindMovByTitleIncorrectId() throws MovieNotFoundException {
		String MovTitle = "Rush Hour";
	      MovieNotFoundException ex = assertThrows(MovieNotFoundException.class, ()->{
	    	List<Movie> mlt = new ArrayList<>();
	  		when(movieRepository.findBymovTitle(MovTitle)).thenReturn(mlt);
	  		movieServiceImpl.findBymovTitle(MovTitle);
	        });
	        assertEquals("Movie not found...",ex.getMessage());
	        verify(movieRepository).findBymovTitle(MovTitle);
	  }
	
	 @Test
	    public void testDeleteByMovieId_ExistingMovie() throws MovieNotFoundException {
	        String movieId = "RR123";
	        Movie movie = new Movie();
	        when(movieRepository.findById(movieId)).thenReturn(Optional.of(movie));

	        movieServiceImpl.deleteByMovieId(movieId);
//	        verify(movieRepository, times(1)).deleteById(movieId);
	    }

	    @Test
	    public void testDeleteByMovieId_NonExistingMovie() {
	        String movieId = "RR123";
	        when(movieRepository.findById(movieId)).thenReturn(Optional.empty());
	        
	        assertThrows(MovieNotFoundException.class, () -> movieServiceImpl.deleteByMovieId(movieId));
	        verify(movieRepository, never()).deleteById(movieId);
	    }
	
	
	

}
