//package com.cts.developmenttwo.servicetest;
//
//import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
//import static org.junit.jupiter.api.Assertions.assertEquals;
//import static org.junit.jupiter.api.Assertions.assertFalse;
//import static org.junit.jupiter.api.Assertions.assertNotNull;
//import static org.junit.jupiter.api.Assertions.assertNull;
//import static org.junit.jupiter.api.Assertions.assertThrows;
//import static org.mockito.ArgumentMatchers.any;
//import static org.mockito.ArgumentMatchers.anyInt;
//import static org.mockito.Mockito.never;
//import static org.mockito.Mockito.times;
//import static org.mockito.Mockito.verify;
//import static org.mockito.Mockito.when;
//
//import java.time.LocalDate;
//import java.util.ArrayList;
//import java.util.List;
//import java.util.Optional;
//
//import org.assertj.core.api.Assertions;
//import org.junit.jupiter.api.Test;
//import org.junit.jupiter.api.extension.ExtendWith;
//import org.mockito.InjectMocks;
//import org.mockito.Mock;
//import org.springframework.test.context.junit.jupiter.SpringExtension;
//
//import com.cts.dao.MovieRepository;
//import com.cts.dao.OrdersRepository;
//import com.cts.dao.UsersRepository;
//import com.cts.exception.MovieNotFoundException;
//import com.cts.exception.OrderNotFoundException;
//import com.cts.exception.UserNotFoundException;
//import com.cts.model.Movie;
//import com.cts.model.Orders;
//import com.cts.model.Users;
//import com.cts.pojo.OrderModel;
//import com.cts.service.MovieService;
//import com.cts.service.MovieServiceImpl;
//import com.cts.service.OrderServiceImpl;
//import com.cts.service.UsersService;
//import com.cts.service.UsersServiceImpl;
//import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateDeserializer;
//
//@ExtendWith(SpringExtension.class)
//public class OrdersServiceTest {
//	
//	@InjectMocks
//	OrderServiceImpl orderserviceImpl;
//	
//	@Mock
//	OrdersRepository ordersRepository;
//	
//	@Mock
//	UsersRepository usersRepository;
//	
//	@Mock
//	MovieRepository movieRepository;
//	
//	@Mock
//	private MovieService movieService;
//	
//	@Mock
//	private UsersService usersService;
//	
//
//		
//	    @Test
//	    public void testPlaceOrder() throws UserNotFoundException, MovieNotFoundException {
//
//	        OrderModel orderModel = new OrderModel();
//	        orderModel.setEmailId("test@example.com");
//	        orderModel.setMovList(List.of("movieId1", "movieId2"));
//	        
//	        
//	        Users users = new Users();
//	        users.setEmailId("test@example.com");
//	        when(usersService.findByUserId("test@example.com")).thenReturn(users);
//	        
//	        
//	        Movie movie1 = new Movie();
//	        movie1.setMovId("movieId1");
//	        movie1.setPrice(10.0);
//	        
//	        when(movieService.findByMovieId("movieId1")).thenReturn(movie1);
//	        
//	        Movie movie2 = new Movie();
//	        movie2.setMovId("movieId2");
//	        movie2.setPrice(20.0);
//	        
//	        when(movieService.findByMovieId("movieId2")).thenReturn(movie2);
//	        
//	        Orders savedOrder = new Orders();
//	        savedOrder.setOrderId(1);
//	        savedOrder.setUsers(users);
//	        savedOrder.setPurchaseDate(LocalDate.now());
//	        savedOrder.setMovieList(List.of(movie1, movie2));
//	        savedOrder.setTotalQuantity(2);
//	        savedOrder.setTotalPrice(30.0);
//	        savedOrder.setStatus("Pending");
//	        
//	        
//	        when(ordersRepository.save(any(Orders.class))).thenReturn(savedOrder);
//	        
//	        Orders result = orderserviceImpl.placeOrder(orderModel);
//	        assertEquals(users, result.getUsers());
//	        assertEquals(LocalDate.now(), result.getPurchaseDate());
//	        assertEquals(2, result.getTotalQuantity());
//	        assertEquals(30.0, result.getTotalPrice());
//	        assertEquals(List.of(movie1, movie2), result.getMovieList());
//	        assertEquals("Pending", result.getStatus());
//
//	    }
//	    
//	        @Test
//	        public void testFindOrdersByUserId() throws OrderNotFoundException, UserNotFoundException {
//	            String emailId = "test@example.com";
//	            Users user = new Users();
//	            user.setEmailId(emailId);
//	            List<Orders> ordersList = new ArrayList<>();
//	            Orders order1 = new Orders();
//	            order1.setOrderId(1);
//	            Orders order2 = new Orders();
//	            order2.setOrderId(2);
//	            ordersList.add(order1);
//	            ordersList.add(order2);
//	            when(usersService.findByUserId(emailId)).thenReturn(user);
//	            when(ordersRepository.findOrdersByUserId(emailId)).thenReturn(ordersList);
//
//	            List<Orders> result = orderserviceImpl.findOrdersByUserId(emailId);
//	            assertNotNull(result);
//	            assertEquals(2, result.size());
//	            assertEquals(1, result.get(0).getOrderId());
//	            assertEquals(2, result.get(1).getOrderId());
//
//	            verify(usersService, times(1)).findByUserId(emailId);
////	            verify(ordersRepository, times(1)).findOrdersByUserId(anyString);
//	        }
//
//
//	        @Test
//	        public void testFindOrdersByUserId_UserNotFoundException() throws UserNotFoundException{
//
//	            String emailId = "nonexistent@example.com";
//	            when(usersService.findByUserId(emailId)).thenThrow(UserNotFoundException.class);
//	            assertThrows(UserNotFoundException.class, () -> orderserviceImpl.findOrdersByUserId(emailId));
//	            verify(usersService, times(1)).findByUserId(emailId);
//	            verify(ordersRepository, never()).findOrdersByUserId(emailId);
//	        }
//	        @Test
//	        public void testFindOrdersByUserId_OrderNotFoundException() throws UserNotFoundException{
//	            String emailId = "test@example.com";
//	            Users user = new Users();
//	            user.setEmailId(emailId);
//	            when(usersService.findByUserId(emailId)).thenReturn(user);
//	            when(ordersRepository.findOrdersByUserId(emailId)).thenReturn(new ArrayList<>());
//
//	            assertThrows(OrderNotFoundException.class, () -> orderserviceImpl.findOrdersByUserId(emailId));
//	            verify(usersService, times(1)).findByUserId(emailId);
//	            verify(ordersRepository, times(1)).findOrdersByUserId(emailId);
//
//	        }
//	       
//	        @Test
//	        public void testDeleteOrderById() throws OrderNotFoundException {
//	        int orderId = 1;
//	        Orders order = new Orders();
//	        order.setOrderId(orderId);
//
//	        when(ordersRepository.findById(orderId)).thenReturn(Optional.of(order));
//	        assertDoesNotThrow(() -> orderserviceImpl.deleteOrderById(orderId));
//
//	        verify(ordersRepository, times(1)).findById(orderId);
//	        verify(ordersRepository, times(1)).deleteById(orderId);
//	        }
//
//	        @Test
//	        public void testDeleteOrderById_OrderNotFoundException() {
//	        int orderId = 1;
//
//	        when(ordersRepository.findById(orderId)).thenReturn(Optional.empty());
//
//	        assertThrows(OrderNotFoundException.class, () -> orderserviceImpl.deleteOrderById(orderId));
//
//	        verify(ordersRepository, times(1)).findById(orderId);
//	        verify(ordersRepository, never()).deleteById(anyInt());
//	        }
//	        
////	        @Test
////	        public void testApproval() throws OrderNotFoundException{
////	        	
////	        int orderId = 1;
////	        Orders order = new Orders();
////	        order.setOrderId(orderId);
////	        order.setStatus("Pending");
////	        when(ordersRepository.findbyorderId(orderId)).thenReturn(order);
////	        order.setStatus("Success");
////	        when(ordersRepository.save(order)).thenReturn(order);
////	        Orders result = orderserviceImpl.approval(orderId,true);
////
////	        assertEquals("Success", result.getStatus());
////	        verify(ordersRepository, times(1)).findbyorderId(orderId);
////	        verify(ordersRepository, times(1)).save(order);
////	        }
//	        
//	        @Test
//	        public void testApproval_OrderFound_Success() throws OrderNotFoundException {
//	        int orderId = 1;
//	        Orders order = new Orders();
//	        order.setOrderId(orderId);
//	        order.setStatus("Pending");
//	        boolean br = true;
//
//	        when(ordersRepository.findbyorderId(orderId)).thenReturn(order);
//	        order.setStatus("Success");
//	        when(ordersRepository.save(order)).thenReturn(order);
//	        Orders result = orderserviceImpl.approval(orderId, br);
//
//	        assertEquals("Success", result.getStatus());
//
//	        verify(ordersRepository, times(1)).findbyorderId(orderId);
//	        verify(ordersRepository, times(1)).save(order);
//	        }
//
//	        @Test
//	        public void testApproval_OrderFound_Failure() throws OrderNotFoundException {
//	        int orderId = 1;
//	        Orders order = new Orders();
//	        order.setOrderId(orderId);
//	        order.setStatus("Pending");
//	        boolean br = false;
//
//	        when(ordersRepository.findbyorderId(orderId)).thenReturn(order);
//	        order.setStatus("Failure");
//	        when(ordersRepository.save(order)).thenReturn(order);
//	        Orders result = orderserviceImpl.approval(orderId, br);
//	        assertEquals("Canceled", result.getStatus());
//
//	        verify(ordersRepository, times(1)).findbyorderId(orderId);
//	        verify(ordersRepository, times(1)).save(order);
//	        }
//
//	        @Test
//	        public void testApproval_OrderNotFoundException() {
//	        int orderId = 1;
//	        boolean br = true;
//
//	        when(ordersRepository.findbyorderId(orderId)).thenReturn(null);
//
//	        assertThrows(OrderNotFoundException.class, () -> orderserviceImpl.approval(orderId, br));
//
//	        verify(ordersRepository, times(1)).findbyorderId(orderId);
//	        verify(ordersRepository, never()).save(any(Orders.class));
//	        }
//	        
//	        @Test
//	        public void test_FindallOrders() {
//	        	LocalDate psd = null;
//				Orders o1 = new Orders(1, 100, 1000.00, psd , "pending", new ArrayList<>(), new Users());
//				Orders o2 = new Orders(1, 130, 1300.00, psd , "pending", new ArrayList<>(), new Users());
//				
//				List<Orders> oList = new ArrayList<>();
//				oList.add(o2);
//				oList.add(o1);				
//				when(orderserviceImpl.findAllOrders()).thenReturn(oList);
//				
//				List<Orders> oList2 = orderserviceImpl.findAllOrders();
//				assertEquals(2, oList2.size());
//			}
//	        
//	        @Test
//	        public void test_FindallOrderById() throws OrderNotFoundException{
////	        	LocalDate psd = null;
////	  
////				Orders o1 = new Orders(1, 100, 1000.00, psd , "pending", new ArrayList<>(), new Users());
////				when(orderserviceImpl.FindOrderById(1)).thenReturn(o1);
////				Orders o = orderserviceImpl.FindOrderById(2);
//				assertThrows(OrderNotFoundException.class, () -> orderserviceImpl.FindOrderById(2));
//	        } 
//	        
//	        
//}
//

package com.cts.developmenttwo.servicetest;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.cts.dao.MovieRepository;
import com.cts.dao.OrdersRepository;
import com.cts.dao.UsersRepository;
import com.cts.exception.MovieNotFoundException;
import com.cts.exception.OrderNotFoundException;
import com.cts.exception.UserNotFoundException;
import com.cts.model.Movie;
import com.cts.model.Orders;
import com.cts.model.Users;
import com.cts.pojo.OrderModel;
import com.cts.service.MovieService;
import com.cts.service.MovieServiceImpl;
import com.cts.service.OrderServiceImpl;
import com.cts.service.UsersService;
import com.cts.service.UsersServiceImpl;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateDeserializer;

@ExtendWith(SpringExtension.class)
public class OrdersServiceTest {
	
	@InjectMocks
	OrderServiceImpl orderserviceImpl;
	
	@Mock
	OrdersRepository ordersRepository;
	
	@Mock
	UsersRepository usersRepository;
	
	@Mock
	MovieRepository movieRepository;
	
	@Mock
	private MovieService movieService;
	
	@Mock
	private UsersService usersService;
	

		
	    @Test
	    public void testPlaceOrder() throws UserNotFoundException, MovieNotFoundException {

	        OrderModel orderModel = new OrderModel();
	        orderModel.setEmailId("test@example.com");
	        orderModel.setMovList(List.of("movieId1", "movieId2"));
	        
	        
	        Users users = new Users();
	        users.setEmailId("test@example.com");
	        when(usersService.findByUserId("test@example.com")).thenReturn(users);
	        
	        
	        Movie movie1 = new Movie();
	        movie1.setMovId("movieId1");
	        movie1.setPrice(10.0);
	        
	        when(movieService.findByMovieId("movieId1")).thenReturn(movie1);
	        
	        Movie movie2 = new Movie();
	        movie2.setMovId("movieId2");
	        movie2.setPrice(20.0);
	        
	        when(movieService.findByMovieId("movieId2")).thenReturn(movie2);
	        
	        Orders savedOrder = new Orders();
	        savedOrder.setOrderId(1);
	        savedOrder.setUsers(users);
	        savedOrder.setPurchaseDate(LocalDate.now());
	        savedOrder.setMovieList(List.of(movie1, movie2));
	        savedOrder.setTotalQuantity(2);
	        savedOrder.setTotalPrice(30.0);
	        savedOrder.setStatus("Pending");
	        
	        
	        when(ordersRepository.save(any(Orders.class))).thenReturn(savedOrder);
	        
	        Orders result = orderserviceImpl.placeOrder(orderModel);
	        assertEquals(users, result.getUsers());
	        assertEquals(LocalDate.now(), result.getPurchaseDate());
	        assertEquals(2, result.getTotalQuantity());
	        assertEquals(30.0, result.getTotalPrice());
	        assertEquals(List.of(movie1, movie2), result.getMovieList());
	        assertEquals("Pending", result.getStatus());

	    }
	    
	        @Test
	        public void testFindOrdersByUserId() throws OrderNotFoundException, UserNotFoundException {
	            String emailId = "test@example.com";
	            Users user = new Users();
	            user.setEmailId(emailId);
	            List<Orders> ordersList = new ArrayList<>();
	            Orders order1 = new Orders();
	            order1.setOrderId(1);
	            Orders order2 = new Orders();
	            order2.setOrderId(2);
	            ordersList.add(order1);
	            ordersList.add(order2);
	            when(usersService.findByUserId(emailId)).thenReturn(user);
	            when(ordersRepository.findOrdersByUserId(emailId)).thenReturn(ordersList);

	            List<Orders> result = orderserviceImpl.findOrdersByUserId(emailId);
	            assertNotNull(result);
	            assertEquals(2, result.size());
	            assertEquals(1, result.get(0).getOrderId());
	            assertEquals(2, result.get(1).getOrderId());

	            verify(usersService, times(1)).findByUserId(emailId);
//	            verify(ordersRepository, times(1)).findOrdersByUserId(anyString);
	        }


	        @Test
	        public void testFindOrdersByUserId_UserNotFoundException() throws UserNotFoundException{

	            String emailId = "nonexistent@example.com";
	            when(usersService.findByUserId(emailId)).thenThrow(UserNotFoundException.class);
	            assertThrows(UserNotFoundException.class, () -> orderserviceImpl.findOrdersByUserId(emailId));
	            verify(usersService, times(1)).findByUserId(emailId);
	            verify(ordersRepository, never()).findOrdersByUserId(emailId);
	        }
	        @Test
	        public void testFindOrdersByUserId_OrderNotFoundException() throws UserNotFoundException{
	            String emailId = "test@example.com";
	            Users user = new Users();
	            user.setEmailId(emailId);
	            when(usersService.findByUserId(emailId)).thenReturn(user);
	            when(ordersRepository.findOrdersByUserId(emailId)).thenReturn(new ArrayList<>());

	            assertThrows(OrderNotFoundException.class, () -> orderserviceImpl.findOrdersByUserId(emailId));
	            verify(usersService, times(1)).findByUserId(emailId);
	            verify(ordersRepository, times(1)).findOrdersByUserId(emailId);

	        }
	       
	        @Test
	        public void testDeleteOrderById() throws OrderNotFoundException {
	        int orderId = 1;
	        Orders order = new Orders();
	        order.setOrderId(orderId);

	        when(ordersRepository.findById(orderId)).thenReturn(Optional.of(order));
	        assertDoesNotThrow(() -> orderserviceImpl.deleteOrderById(orderId));

	        verify(ordersRepository, times(1)).findById(orderId);
	        verify(ordersRepository, times(1)).deleteById(orderId);
	        }

	        @Test
	        public void testDeleteOrderById_OrderNotFoundException() {
	        int orderId = 1;

	        when(ordersRepository.findById(orderId)).thenReturn(Optional.empty());

	        assertThrows(OrderNotFoundException.class, () -> orderserviceImpl.deleteOrderById(orderId));

	        verify(ordersRepository, times(1)).findById(orderId);
	        verify(ordersRepository, never()).deleteById(anyInt());
	        }
	        
	        
	        @Test
	        public void testApproval_OrderFound_Success() throws OrderNotFoundException {
	        int orderId = 1;
	        Orders order = new Orders();
	        order.setOrderId(orderId);
	        order.setStatus("Pending");
	        boolean br = true;

	        when(ordersRepository.findbyorderId(orderId)).thenReturn(order);
	        order.setStatus("Success");
	        when(ordersRepository.save(order)).thenReturn(order);
	        Orders result = orderserviceImpl.approval(orderId, br);

	        assertEquals("Success", result.getStatus());

	        verify(ordersRepository, times(1)).findbyorderId(orderId);
	        verify(ordersRepository, times(1)).save(order);
	        }

	        @Test
	        public void testApproval_OrderFound_Failure() throws OrderNotFoundException {
	        int orderId = 1;
	        Orders order = new Orders();
	        order.setOrderId(orderId);
	        order.setStatus("Pending");
	        boolean br = false;

	        when(ordersRepository.findbyorderId(orderId)).thenReturn(order);
	        order.setStatus("Failure");
	        when(ordersRepository.save(order)).thenReturn(order);
	        Orders result = orderserviceImpl.approval(orderId, br);
	        assertEquals("Canceled", result.getStatus());

	        verify(ordersRepository, times(1)).findbyorderId(orderId);
	        verify(ordersRepository, times(1)).save(order);
	        }

	        @Test
	        public void testApproval_OrderNotFoundException() {
	        int orderId = 1;
	        boolean br = true;

	        when(ordersRepository.findbyorderId(orderId)).thenReturn(null);

	        assertThrows(OrderNotFoundException.class, () -> orderserviceImpl.approval(orderId, br));

	        verify(ordersRepository, times(1)).findbyorderId(orderId);
	        verify(ordersRepository, never()).save(any(Orders.class));
	        }
	        
	        @Test
	        public void test_FindallOrders() {
	        	LocalDate psd = null;
				Orders o1 = new Orders(1, 100, 1000.00, psd , "pending", new ArrayList<>(), new Users());
				Orders o2 = new Orders(1, 130, 1300.00, psd , "pending", new ArrayList<>(), new Users());
				
				List<Orders> oList = new ArrayList<>();
				oList.add(o2);
				oList.add(o1);				
				when(orderserviceImpl.findAllOrders()).thenReturn(oList);
				
				List<Orders> oList2 = orderserviceImpl.findAllOrders();
				assertEquals(2, oList2.size());
			}
	        
	        @Test
	        public void test_FindallOrderById() throws OrderNotFoundException{

				assertThrows(OrderNotFoundException.class, () -> orderserviceImpl.FindOrderById(2));
	        } 
	        
	        @Test
	        void testFindOrderById() throws OrderNotFoundException {
	            // Arrange
	            int orderId = 1;
	            Orders order = new Orders(); // Create a sample order
	            when(ordersRepository.findById(orderId)).thenReturn(Optional.of(order));

	            // Act
	            Orders result = orderserviceImpl.FindOrderById(orderId);

	            // Assert
	            assertEquals(order, result);
	            verify(ordersRepository, times(1)).findById(orderId);
	        }
	        
	        
}




