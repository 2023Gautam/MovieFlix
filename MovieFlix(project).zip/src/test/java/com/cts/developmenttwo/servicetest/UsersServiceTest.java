//package com.cts.developmenttwo.servicetest;
//
//import static org.junit.jupiter.api.Assertions.assertEquals;
//import static org.junit.jupiter.api.Assertions.assertThrows;
//import static org.mockito.ArgumentMatchers.any;
//import static org.mockito.Mockito.times;
//import static org.mockito.Mockito.verify;
//import static org.mockito.Mockito.when;
//
//import java.util.Optional;
//
//import org.junit.jupiter.api.Test;
//import org.junit.jupiter.api.extension.ExtendWith;
//import org.mockito.InjectMocks;
//import org.mockito.Mock;
//import org.springframework.test.context.junit.jupiter.SpringExtension;
//
//import com.cts.dao.UsersRepository;
////import com.cts.exception.InvalidException;
//import com.cts.exception.UserNotFoundException;
//import com.cts.model.Users;
//import com.cts.pojo.UsersModel;
//import com.cts.service.UsersServiceImpl;
//
//@ExtendWith(SpringExtension.class)
//public class UsersServiceTest {
//	
//	@Mock
//	UsersRepository usersRepository;
//	
//	@InjectMocks
//	UsersServiceImpl usersServiceImpl;
//	
//	@Test
//	public void addCustTest() throws UserNotFoundException  {
//		UsersModel customerModel = new UsersModel();
//		customerModel.setEmailId("maji@gmail.com");
//		customerModel.setUserName("Sayantan Maji");
//		customerModel.setPassword("2313");
//		
//		Users users = new Users();
//		users.setEmailId(customerModel.getEmailId());
//		users.setUserName(customerModel.getUserName());
//		users.setPassword(customerModel.getPassword());
//		users.setCatagory("cust");
//		
//		when(usersRepository.save(any(Users.class))).thenReturn(users);
//		
//		Users result = usersServiceImpl.addCust(customerModel);
//		assertEquals(users.getEmailId(), result.getEmailId());
//		assertEquals(users.getUserName(), result.getUserName());
//		assertEquals(users.getPassword(), result.getPassword());
//		assertEquals(users.getCatagory(), result.getCatagory());
//		verify(usersRepository).save(any(Users.class));
//		
//	}
//	
//	@Test
//	public void findByUserIdTest() throws UserNotFoundException {
//		Users users = new Users();
//		users.setEmailId("maji@gmail.com");
//		users.setUserName("Sayantan Maji");
//		users.setPassword("2313");
//		users.setCatagory("cust");
//
//		when(usersRepository.findById("maji@gmail.com")).thenReturn(Optional.of(users));
//		 
//		Users result = usersServiceImpl.findByUserId("maji@gmail.com");
//		
////		assertEquals("maji@gmail.com", result.getEmailId());
////		assertEquals("Sayantan Maji", result.getUserName());
////		assertEquals("2313", result.getPassword());
////		assertEquals("cust", result.getCatagory());
//		assertEquals(users.getEmailId(), result.getEmailId());
//		assertEquals(users.getUserName(), result.getUserName());
//		assertEquals(users.getPassword(), result.getPassword());
//		assertEquals(users.getCatagory(), result.getCatagory());
////		verify(usersRepository).findById(result.getEmailId());
//	}
//	
//	
//	@Test
//	public void userLoginTest() throws UserNotFoundException {
//		Users users = new Users();
//		users.setEmailId("maji@gmail.com");
//		users.setUserName("Sayantan Maji");
//		users.setPassword("2313");
//		users.setCatagory("cust");
//		
//		when(usersRepository.UserLogin("maji@gmail.com", "2313")).thenReturn(users);
//		
//		Users result = usersServiceImpl.customerLogin("maji@gmail.com", "2313");
//		assertEquals(users.getEmailId(), result.getEmailId());
//		assertEquals(users.getUserName(), result.getUserName());
//		assertEquals(users.getPassword(), result.getPassword());
//		assertEquals(users.getCatagory(), result.getCatagory());
//		
//	}
//	
//	@Test
//	public void adminLoginTest() throws UserNotFoundException {
//		Users users = new Users();
//		users.setEmailId("basu@gmail.com");
//		users.setUserName("Gautam Basu");
//		users.setPassword("1432");
//		users.setCatagory("adm");
//		
//		when(usersRepository.adminsLogin("basu@gmail.com", "1432")).thenReturn(users);
//		
//		Users result = usersServiceImpl.adminsLogin("basu@gmail.com", "1432");
//		assertEquals(users.getEmailId(), result.getEmailId());
//		assertEquals(users.getUserName(), result.getUserName());
//		assertEquals(users.getPassword(), result.getPassword());
//		assertEquals(users.getCatagory(), result.getCatagory());
//		
//	}
//	
//	@Test
//	public void adminLoginTestinvalid(){
//		String eml = "wrong@gmail.com";
//		String pass = "1234";
//		when(usersRepository.adminsLogin(eml,pass)).thenReturn(null);
//		
//		assertThrows(UserNotFoundException.class, () -> usersServiceImpl.adminsLogin(eml,pass));
//		verify(usersRepository, times(1)).adminsLogin(eml,pass);
//	}
//	
//	@Test
//	public void userLoginTestinvalid(){
//		String eml = "wrong@gmail.com";
//		String pass = "1234";
//		when(usersRepository.UserLogin(eml,pass)).thenReturn(null);
//		
//		assertThrows(UserNotFoundException.class, () -> usersServiceImpl.customerLogin(eml,pass));
//		verify(usersRepository, times(1)).UserLogin(eml,pass);
//	}
//	
//	@Test
//	public void findByUserIdInvalid(){
//		String eml = "wrong@gmail.com";
//		when(usersRepository.findById(eml)).thenReturn(Optional.empty());
//		
//		assertThrows(UserNotFoundException.class, () -> usersServiceImpl.findByUserId(eml));
//		verify(usersRepository, times(1)).findById(eml);
//	}
//	
//
//}

package com.cts.developmenttwo.servicetest;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.cts.dao.UsersRepository;
//import com.cts.exception.InvalidException;
import com.cts.exception.UserNotFoundException;
import com.cts.model.Users;
import com.cts.pojo.UsersModel;
import com.cts.service.UsersServiceImpl;

@ExtendWith(SpringExtension.class)
public class UsersServiceTest {
	
	@Mock
	UsersRepository usersRepository;
	
	@InjectMocks
	UsersServiceImpl usersServiceImpl;
	
	@Test
	public void addCustTest() throws UserNotFoundException  {
		UsersModel customerModel = new UsersModel();
		customerModel.setEmailId("maji@gmail.com");
		customerModel.setUserName("Sayantan Maji");
		customerModel.setPassword("2313");
		
		Users users = new Users();
		users.setEmailId(customerModel.getEmailId());
		users.setUserName(customerModel.getUserName());
		users.setPassword(customerModel.getPassword());
		users.setCatagory("cust");
		
		when(usersRepository.save(any(Users.class))).thenReturn(users);
		
		Users result = usersServiceImpl.addCust(customerModel);
		assertEquals(users.getEmailId(), result.getEmailId());
		assertEquals(users.getUserName(), result.getUserName());
		assertEquals(users.getPassword(), result.getPassword());
		assertEquals(users.getCatagory(), result.getCatagory());
		verify(usersRepository).save(any(Users.class));
		
	}
	
	@Test
    void testAddCust_EmailAlreadyExists() throws UserNotFoundException {

        UsersModel usersModel = new UsersModel("John", "john@example.com", "password");
        Users existingUser = new Users();
        when(usersRepository.findById(usersModel.getEmailId())).thenReturn(Optional.of(existingUser));

        assertThrows(UserNotFoundException.class, () -> usersServiceImpl.addCust(usersModel));
        verify(usersRepository, times(1)).findById(usersModel.getEmailId());
        verify(usersRepository, never()).save(any(Users.class));
    }
	
	@Test
	public void findByUserIdTest() throws UserNotFoundException {
		Users users = new Users();
		users.setEmailId("maji@gmail.com");
		users.setUserName("Sayantan Maji");
		users.setPassword("2313");
		users.setCatagory("cust");

		when(usersRepository.findById("maji@gmail.com")).thenReturn(Optional.of(users));
		 
		Users result = usersServiceImpl.findByUserId("maji@gmail.com");
		
		assertEquals(users.getEmailId(), result.getEmailId());
		assertEquals(users.getUserName(), result.getUserName());
		assertEquals(users.getPassword(), result.getPassword());
		assertEquals(users.getCatagory(), result.getCatagory());
	}
	
	
	@Test
	public void userLoginTest() throws UserNotFoundException {
		Users users = new Users();
		users.setEmailId("maji@gmail.com");
		users.setUserName("Sayantan Maji");
		users.setPassword("2313");
		users.setCatagory("cust");
		
		when(usersRepository.UserLogin("maji@gmail.com", "2313")).thenReturn(users);
		
		Users result = usersServiceImpl.customerLogin("maji@gmail.com", "2313");
		assertEquals(users.getEmailId(), result.getEmailId());
		assertEquals(users.getUserName(), result.getUserName());
		assertEquals(users.getPassword(), result.getPassword());
		assertEquals(users.getCatagory(), result.getCatagory());
		
	}
	
	@Test
	public void adminLoginTest() throws UserNotFoundException {
		Users users = new Users();
		users.setEmailId("basu@gmail.com");
		users.setUserName("Gautam Basu");
		users.setPassword("1432");
		users.setCatagory("adm");
		
		when(usersRepository.adminsLogin("basu@gmail.com", "1432")).thenReturn(users);
		
		Users result = usersServiceImpl.adminsLogin("basu@gmail.com", "1432");
		assertEquals(users.getEmailId(), result.getEmailId());
		assertEquals(users.getUserName(), result.getUserName());
		assertEquals(users.getPassword(), result.getPassword());
		assertEquals(users.getCatagory(), result.getCatagory());
		
	}
	
	@Test
	public void adminLoginTestinvalid(){
		String eml = "wrong@gmail.com";
		String pass = "1234";
		when(usersRepository.adminsLogin(eml,pass)).thenReturn(null);
		
		assertThrows(UserNotFoundException.class, () -> usersServiceImpl.adminsLogin(eml,pass));
		verify(usersRepository, times(1)).adminsLogin(eml,pass);
	}
	
	@Test
	public void userLoginTestinvalid(){
		String eml = "wrong@gmail.com";
		String pass = "1234";
		when(usersRepository.UserLogin(eml,pass)).thenReturn(null);
		
		assertThrows(UserNotFoundException.class, () -> usersServiceImpl.customerLogin(eml,pass));
		verify(usersRepository, times(1)).UserLogin(eml,pass);
	}
	
	@Test
	public void findByUserIdInvalid(){
		String eml = "wrong@gmail.com";
		when(usersRepository.findById(eml)).thenReturn(Optional.empty());
		
		assertThrows(UserNotFoundException.class, () -> usersServiceImpl.findByUserId(eml));
		verify(usersRepository, times(1)).findById(eml);
	}
	

}

