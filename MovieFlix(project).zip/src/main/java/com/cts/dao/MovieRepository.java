package com.cts.dao;

import java.util.List;
//import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cts.model.Movie;

@Repository
public interface MovieRepository extends JpaRepository<Movie, String>{
	
	@Query(value = "select o from Movie o where o.movGenre = ?1 and o.avail=true")
	public List<Movie> findBymovGenre(String movGenre);
	
	@Query(value = "select o from Movie o where o.movTitle like %?1% and o.avail=true")
	public List<Movie> findBymovTitle(String movTitle);

	@Query(value = "select o from Movie o where o.avail=true")
	public List<Movie> findByAvail();

	//public void deleteByMovieId(String movieId);

}
