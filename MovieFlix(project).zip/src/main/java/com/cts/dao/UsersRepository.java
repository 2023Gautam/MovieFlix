package com.cts.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cts.model.Users;

@Repository
public interface UsersRepository extends JpaRepository<Users, String>{

	@Query(value="select u from Users u where u.emailId=?1 and u.password=?2 and u.catagory='adm'")
	Users adminsLogin(String emailId, String password);

	@Query(value="select u from Users u where u.emailId=?1 and u.password=?2 and u.catagory='cust'")
	Users UserLogin(String emailId, String password);
}
