package com.cts.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.exception.MovieNotFoundException;
import com.cts.exception.OrderNotFoundException;
import com.cts.exception.UserNotFoundException;
import com.cts.model.Movie;
import com.cts.model.Orders;
import com.cts.pojo.ApiResponce;
import com.cts.pojo.ApprovalModel;
import com.cts.pojo.OrderModel;
import com.cts.service.OrdersService;

import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@CrossOrigin("http://localhost:4200")
@RequestMapping("/api/orders")
public class OrdersController {
	
	@Autowired
	private OrdersService oservice;
	
	/**
	 * This End Point is use to Place a new orders.
	 * @param orderModel
	 * @return
	 * @throws UserNotFoundException
	 * @throws MovieNotFoundException
	 */
	@PostMapping("/placeOrder")
	public ResponseEntity<Orders> placeOrder(@Valid @RequestBody OrderModel orderModel) throws UserNotFoundException, MovieNotFoundException {
		log.info("START");
		Orders placeOrder = oservice.placeOrder(orderModel);
		log.debug("Order placed: {}", placeOrder );
		log.info("END");
		return new ResponseEntity<>(placeOrder, HttpStatus.OK);
	}
	@GetMapping("/showAllOrders")
	public ResponseEntity<List<Orders>> findAllOrders(){
		log.info("START");
		List<Orders> findAllOrders = oservice.findAllOrders();
		log.info("All Movies: {}", findAllOrders);
		log.info("END");
		return new ResponseEntity<>(findAllOrders,HttpStatus.OK);
	}

	/**
	 * This End point is use to delete existing order and its details.
	 * @param orderId
	 * @return
	 * @throws OrderNotFoundException
	 */
	@DeleteMapping("/deleteOrder/{orderId}")
	public ResponseEntity<ApiResponce> deleteOrderById(@PathVariable("orderId") int orderId) throws OrderNotFoundException {
		log.info("START");
		oservice.deleteOrderById(orderId);
		log.info("END");
		ApiResponce aresp = new ApiResponce();
		aresp.setStatus("deleted");
		return  new ResponseEntity<>(aresp, HttpStatus.OK);
	}
	
	/**
	 * This End Point is use to find all order details using buyer's Id.
	 * @param emailId
	 * @return
	 * @throws OrderNotFoundException
	 * @throws UserNotFoundException
	 */
	@GetMapping("/findOrderByUserId/{emailId}")
	public ResponseEntity<List<Orders>> findOrdersByUserId(@PathVariable("emailId") String emailId) throws OrderNotFoundException, UserNotFoundException {
		log.info("START");
		List<Orders> findOrdersByUserId = oservice.findOrdersByUserId(emailId);
		log.debug("All Orders: {}", findOrdersByUserId);
		log.info("END");
		return new ResponseEntity<>(findOrdersByUserId, HttpStatus.OK);
	}
	
	@PutMapping("/approval")
	public ResponseEntity<Orders> approval(@RequestBody ApprovalModel approvalModel) throws OrderNotFoundException{
		log.info("START");
		int orderId = approvalModel.orderId;
		boolean br = approvalModel.status;
		Orders approval = oservice.approval(orderId, br);
		log.debug("Approved: {}", approval);
		log.info("END");
		return new ResponseEntity<>(approval, HttpStatus.OK);
	}
	
	@GetMapping("/findOrderByOrderId/{orderId}")
	public ResponseEntity<Orders> findOrdersByOrderId(@PathVariable("orderId") int orderId) throws OrderNotFoundException, UserNotFoundException {
		log.info("START");
		Orders findOrdersByUserId = oservice.FindOrderById(orderId);
		log.debug("All Orders: {}", findOrdersByUserId);
		log.info("END");
		return new ResponseEntity<>(findOrdersByUserId, HttpStatus.OK);
	}
	

}
