package com.cts.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

//import com.cts.exception.InvalidException;
import com.cts.exception.UserNotFoundException;
import com.cts.model.Users;
import com.cts.pojo.ApiResponce;
import com.cts.pojo.UsersModel;

import com.cts.service.UsersService;

import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@CrossOrigin("http://localhost:4200")
@RequestMapping("/api/users")
public class UsersController {
	
	@Autowired
	private UsersService uservice;
	
	/**
	 * This End Point is use to add new customer to the user's table.
	 * @param uModel
	 * @return
	 * @throws UserNotFoundException 
	 * @throws InvalidException
	 */
	@PostMapping("/customer")
	public ResponseEntity<Users> addCust( @Valid @RequestBody UsersModel uModel) throws UserNotFoundException{
		log.info("START");
		Users Cust = uservice.addCust(uModel);
		log.debug("Added new Cutomer: {}", Cust);
		log.info("END");
		return new ResponseEntity<>(Cust, HttpStatus.OK);
	}
	
	@GetMapping("/{emailId}")
	public ResponseEntity<Users> findByUserId( @PathVariable("emailId") String emailId) throws UserNotFoundException{
		log.info("START");
		Users findByUserId = uservice.findByUserId(emailId);
		log.debug("User Details: {}", findByUserId);
		log.info("END");
		return new ResponseEntity<>(findByUserId, HttpStatus.OK);
	}
	/**
	 * This End Point is to log in users, Customers.
	 * @param umodel
	 * @return
	 * @throws UserNotFoundException
	 */
	@PostMapping("/userLogin")
	public ResponseEntity<ApiResponce> usersLogin(@Valid @RequestBody UsersModel umodel) throws UserNotFoundException{
		log.info("START");
		String email = umodel.getEmailId();
		String pass = umodel.getPassword();
		Users usersLogin = uservice.customerLogin(email,pass);
		log.debug("Logged in User Details: {}", usersLogin);
		String s = usersLogin.getUserName();
		log.info("END");
		ApiResponce aresp = new ApiResponce();
		aresp.setStatus("Welcome! "+ s);
		return new ResponseEntity<>(aresp, HttpStatus.OK);
	}
	/**
	 * This End Point is to log in users, Admin.
	 * @param umodel
	 * @return
	 * @throws UserNotFoundException
	 */
	@PostMapping("/adminLogin")
	public ResponseEntity<ApiResponce> adminLogin(@RequestBody UsersModel umodel) throws UserNotFoundException{
		log.info("START");
		String email = umodel.getEmailId();
		String pass = umodel.getPassword();
		Users usersLogin = uservice.adminsLogin(email,pass);
		log.debug("Logged in User Details: {}", usersLogin);
		String s = usersLogin.getUserName();
		log.info("END");
		ApiResponce aresp = new ApiResponce();
		aresp.setStatus("Welcome! "+ s);
		return new ResponseEntity<>(aresp, HttpStatus.OK);
	}
		
}
