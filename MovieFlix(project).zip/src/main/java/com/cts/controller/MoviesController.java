package com.cts.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
//import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.exception.MovieNotFoundException;
import com.cts.model.Movie;
import com.cts.pojo.ApiResponce;
import com.cts.pojo.MovieModel;
import com.cts.service.MovieService;

import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@CrossOrigin("http://localhost:4200")
@RequestMapping("/api/movies")
public class MoviesController {
	
	@Autowired
	private MovieService mservice;
	/**
	 * This End Point is use to display all the available Movies.
	 * @return
	 */
	@GetMapping("/showAll")
	public ResponseEntity<List<Movie>> findAllMovies(){
		log.info("START");
		List<Movie> findAllMovies = mservice.findAllMovies();
		log.info("All Movies: {}", findAllMovies);
		log.info("END");
		return new ResponseEntity<>(findAllMovies,HttpStatus.OK);
	}
	/**
	 * This End Point is use to get movie details using Movie Id.
	 * @param movieId
	 * @return
	 * @throws MovieNotFoundException
	 */
	@GetMapping("/findById/{movieId}")
	public ResponseEntity<Movie> findByMovieId(@PathVariable("movieId") String movieId) throws MovieNotFoundException {
		log.info("START");
		Movie findByMovieId = mservice.findByMovieId(movieId);
		log.debug("Movie: {}", findByMovieId);
		log.info("END");
		return  new ResponseEntity<>(findByMovieId,HttpStatus.OK);
	}

	
	/**
	 * This End Point is use to Add new Movies to the Movie Table.
	 * @param movie
	 * @return
	 */
	@PostMapping("/AddNew")
	public ResponseEntity<Movie> addMovie(@Valid @RequestBody MovieModel movieModel) {
		log.info("START");
		Movie movie = new Movie(movieModel.getMovId(),movieModel.getMovTitle(),movieModel.getMovGenre(),movieModel.getMovYear(),movieModel.getPrice(), true);
		Movie addMovie = mservice.addMovie(movie);
		log.debug("Movie added: {}", addMovie);
		log.info("END");
		return  new ResponseEntity<>(addMovie,HttpStatus.OK);
	}
	
	/**
	 * This End Point is use to update details of existing movies.
	 * @param movie
	 * @return
	 * @throws MovieNotFoundException
	 */
	@PutMapping("{movieId}")
	public Movie updateMovie(@Valid @RequestBody MovieModel moviemodel) throws MovieNotFoundException {
		String movieId = moviemodel.getMovId();
		mservice.findByMovieId(movieId);
		Movie Rmovie = new Movie(movieId, moviemodel.getMovTitle(), moviemodel.getMovGenre(), moviemodel.getMovYear(), moviemodel.getPrice(), true);
		return mservice.addMovie(Rmovie);
	}
	
	/**
	 * This End Point is use to Find all movies under the same Genre.
	 * @param movieId
	 * @return
	 * @throws MovieNotFoundException
	 */
	@GetMapping("/SearchByGenre/{movieId}")
	public ResponseEntity<List<Movie>> findByMovieGenre(@PathVariable("movieId") String movieId) throws MovieNotFoundException{
		log.info("START");
		List<Movie> findAllMovies = mservice.findBymovGenre(movieId);
		log.info("Found Movies : {}", findAllMovies);
		log.info("END");
		return new ResponseEntity<>(findAllMovies,HttpStatus.OK);
	}
	
	/**
	 * This End Point is use to Find all movies with same Title.
	 * @param movieId
	 * @return
	 * @throws MovieNotFoundException
	 */
	@GetMapping("/SearchByTitle/{movieId}")
	public ResponseEntity<List<Movie>> findByMovieTitle(@PathVariable("movieId") String movieId) throws MovieNotFoundException{
		log.info("START");
		List<Movie> findAllMovies = mservice.findBymovTitle(movieId);
		log.info("Found Movies : {}", findAllMovies);
		log.info("END");
		return new ResponseEntity<>(findAllMovies,HttpStatus.OK);
	}
	
	/**
	 * This End Point is use to delete existing movies.
	 * @param movieId
	 * @return
	 * @throws MovieNotFoundException
	 */
	@DeleteMapping("/DeleteById/{movieId}")
	public ResponseEntity<ApiResponce> deleteByMovieId(@PathVariable("movieId") String movieId) throws MovieNotFoundException{
		log.info("START");
		mservice.deleteByMovieId(movieId);
		log.info("Deleted Successfully");
		log.info("END");
		ApiResponce aresp = new ApiResponce();
		aresp.setStatus("deleted");
		return  new ResponseEntity<>(aresp, HttpStatus.OK);
	}

}
