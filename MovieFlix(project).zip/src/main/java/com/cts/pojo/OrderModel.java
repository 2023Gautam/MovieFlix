package com.cts.pojo;

import java.util.List;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@AllArgsConstructor
@NoArgsConstructor
public class OrderModel {
	
	@NotBlank(message = "Cannot be Blank!")
	@Email(message="Not a Valid Email!")
	private String emailId;
	@NotEmpty(message = "Nothing In The List Yet!")
	private List<String> movList;

}
