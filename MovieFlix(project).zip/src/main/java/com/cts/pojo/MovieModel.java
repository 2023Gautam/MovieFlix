package com.cts.pojo;

import jakarta.validation.constraints.NotBlank;
//import jakarta.validation.constraints.NotEmpty;
//import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class MovieModel {
	
//	@NotBlank
	@Size(max=5, min=5)
	private String MovId;
	
	@NotBlank(message = "Cannot Be Blank!")
	private String movTitle;
	
	@NotBlank(message = "Cannot Be Blank!")
	private String movGenre;
	
	private int movYear;
	
	private double price;
	

}