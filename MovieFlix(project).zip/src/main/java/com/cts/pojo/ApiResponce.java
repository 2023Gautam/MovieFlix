package com.cts.pojo;

import lombok.Data;

@Data
public class ApiResponce {
	
	private String status;
}
