package com.cts.pojo;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UsersModel{
	
	@Email(message = "Not A Valid Email!")
	private String emailId;
	@NotEmpty(message = "User Name Cannot be Null")
	private String userName;
	@Size(min=4, max=4, message = "Password should be of length 4")
	private String Password;
}
