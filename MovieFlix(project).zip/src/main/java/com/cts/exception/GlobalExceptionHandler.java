package com.cts.exception;

import java.util.Date;

//import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class GlobalExceptionHandler {
	
	
	@ExceptionHandler(MovieNotFoundException.class)
	public ResponseEntity<ErrorResponce> handleMovieNotFoundException(MovieNotFoundException e) {
		ErrorResponce errorResponce = new ErrorResponce();
		errorResponce.setDate(new Date());
		errorResponce.setErrorMessage(e.getMessage());
		errorResponce.setHttpStatus(HttpStatus.NOT_FOUND);
		return new ResponseEntity<>(errorResponce, HttpStatus.NOT_FOUND);
	}
	
	@ExceptionHandler(UserNotFoundException.class)
	public ResponseEntity<ErrorResponce> handleUserNotFoundException(UserNotFoundException e) {
		ErrorResponce errorResponce = new ErrorResponce();
		errorResponce.setDate(new Date());
		errorResponce.setErrorMessage(e.getMessage());
		errorResponce.setHttpStatus(HttpStatus.NOT_FOUND);
		return new ResponseEntity<>(errorResponce, HttpStatus.NOT_FOUND);
	}
	
	@ExceptionHandler(Exception.class)
	public ResponseEntity<ErrorResponce> handleException(Exception e) {
		ErrorResponce errorResponce = new ErrorResponce();
		errorResponce.setDate(new Date());
		errorResponce.setErrorMessage(e.getMessage());
		errorResponce.setHttpStatus(HttpStatus.NOT_FOUND);
		return new ResponseEntity<>(errorResponce, HttpStatus.NOT_FOUND);
	}
	
	@ExceptionHandler(OrderNotFoundException.class)
	public ResponseEntity<ErrorResponce> handleOrderNotFoundException(OrderNotFoundException e) {
		ErrorResponce errorResponce = new ErrorResponce();
		errorResponce.setDate(new Date());
		errorResponce.setErrorMessage(e.getMessage());
		errorResponce.setHttpStatus(HttpStatus.NOT_FOUND);
		return new ResponseEntity<>(errorResponce, HttpStatus.NOT_FOUND);
	}

	@ExceptionHandler(MethodArgumentNotValidException.class)
	public ResponseEntity<ErrorResponce> handleOrderNotFoundException(MethodArgumentNotValidException e) {
		ErrorResponce errorResponce = new ErrorResponce();
		errorResponce.setDate(new Date());
		errorResponce.setErrorMessage(e.getMessage());
		errorResponce.setHttpStatus(HttpStatus.NOT_FOUND);
		return new ResponseEntity<>(errorResponce, HttpStatus.NOT_FOUND);
	}
	
	
}
