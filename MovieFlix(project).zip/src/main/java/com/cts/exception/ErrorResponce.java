package com.cts.exception;

import java.util.Date;

import org.springframework.http.HttpStatus;

import lombok.Data;

@Data
public class ErrorResponce {
	
	private Date date;
	private String errorMessage;
	private HttpStatus httpStatus;
}
