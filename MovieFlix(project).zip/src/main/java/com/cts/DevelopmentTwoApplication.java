package com.cts;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
//import org.springframework.context.ApplicationContext;

//import com.cts.exception.MovieNotFoundException;
//import com.cts.exception.UserNotFoundException;
//import com.cts.service.MovieService;
//import com.cts.service.MovieServiceImpl;
//import com.cts.service.OrderServiceImpl;
//import com.cts.service.OrdersService;
//import com.cts.service.UsersService;
//import com.cts.service.UsersServiceImpl;

@SpringBootApplication
public class DevelopmentTwoApplication {

	public static void main(String[] args){
		/*ApplicationContext ctx =*/ SpringApplication.run(DevelopmentTwoApplication.class, args);
//		MovieService movservice = ctx.getBean(MovieServiceImpl.class);
//		UsersService usrService = ctx.getBean(UsersServiceImpl.class);
//		OrdersService odrService = ctx.getBean(OrderServiceImpl.class);
//
//		System.out.println("_____________________________________________");
//		Movie mov = new Movie();  
//		mov.setMovId("TM132");
//		mov.setMovTitle("The Mask");
//		mov.setMovGenre("Comedy");
//		mov.setMovYear(2002);
//		mov.setPrice(70.0);
//		
//		Movie addmovie = movservice.addMovie(mov);
//		System.out.println(addmovie);
		
//		movservice.findAllMovies().forEach(System.out::println);
		
//		movservice.deleteByMovieId(2);
		
//		movservice.findBymovGenre("comedy").forEach(System.out::println);
		
//		movservice.findBymovTitle("The Dark").forEach(System.out::println);
		
//		try {
//			Movie movie = movservice.findByMovieId("AT168");
//			System.out.println(movie);
//		} catch (MovieNotFoundException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		
		
//		System.out.println("_____________________________________________");
		
		
//		Users usr = new Users();
//		usr.setEmailId("sajhasd@jsjs.com");
//		usr.setUserName("abudsa");
//		usr.setPassword("17tdrq51");
//		usr.setCatagory("cust");
//		
//		Users addusr = usrService.addUsers(usr);
//		System.out.println(addusr);
		
		
//		try {
//			Users usr = usrService.findByUserId("gautam@gmai.com");
//			System.out.println(usr);
//		} catch (UserNotFoundException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		
		
//		Boolean br = usrService.usersLogin("sayantan@gmail.com", "say13");
//		if(br==false) {
//			System.out.println("Not a Valid Customer mail or password or not registered customer....");
//		}
//		else {
//			System.out.println("Welcome Customer...");
//		}
		
//		Boolean br = usrService.adminsLogin("sayantan@gmail.com", "say123");
//		if(br==false) {
//			System.out.println("Not a Valid Admin mail or password or not an admin....");
//		}
//		else {
//			System.out.println("Welcome Admin...");
//		}
		
//		System.out.println("_____________________________________________");
		
		
//		List<String> userMovIdList = new ArrayList<>();
//		userMovIdList.add("UH132");
//		userMovIdList.add("AV132");
//		userMovIdList.add("KK121");
//		OrderModel om = new OrderModel();
//		om.setEmailId("maji@gmail.com");
//		om.setMovList(userMovIdList);
//		
//		Orders orders = odrService.placeOrder(om);
//		System.out.println(orders);
//		List<Orders> orlist = odrService.findOrdersByUserId("arnab@gmail.com");
//		System.out.println(orlist);
		
//		odrService.deleteOrderById(7);
		
		
	}

}
