package com.cts.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name="Movie")
public class Movie {
	
	@Id
	@Column(name = "mov_id", length=30)
	private String movId;
	
	@Column(name = "mov_title", length=10000)
	private String movTitle;
	
	@Column(name = "mov_genre", length=30)
	private String movGenre;
	
	@Column(name = "mov_year")
	private int movYear;
	
	@Column(name = "price")
	private double price;
	
	@Column(name = "Avail")
	private boolean avail;

}
