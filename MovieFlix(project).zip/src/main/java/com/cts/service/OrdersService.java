package com.cts.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.cts.exception.MovieNotFoundException;
import com.cts.exception.OrderNotFoundException;
import com.cts.exception.UserNotFoundException;
import com.cts.model.Movie;
import com.cts.model.Orders;
import com.cts.pojo.OrderModel;

@Service
public interface OrdersService {
	
	public Orders placeOrder(OrderModel orderModel) throws UserNotFoundException, MovieNotFoundException;
	public List<Orders> findOrdersByUserId(String userId) throws OrderNotFoundException, UserNotFoundException ;
	void deleteOrderById(int orderId) throws OrderNotFoundException;
	public Orders approval(int orderId, boolean br) throws OrderNotFoundException;
	Orders FindOrderById(int orderId) throws OrderNotFoundException;
	List<Orders> findAllOrders();
	

}
