package com.cts.service;

import java.time.LocalDate;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.dao.OrdersRepository;
import com.cts.exception.MovieNotFoundException;
import com.cts.exception.OrderNotFoundException;
import com.cts.exception.UserNotFoundException;
import com.cts.model.Movie;
import com.cts.model.Orders;
import com.cts.model.Users;
//import com.cts.pojo.MovieModel;
import com.cts.pojo.OrderModel;

import jakarta.transaction.Transactional;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class OrderServiceImpl implements OrdersService{
	
	@Autowired
	UsersService usersService;
	
	@Autowired
	MovieService movieService;

	@Autowired
	OrdersRepository ordersRepository;
	
	@Transactional
	@Override
	public Orders placeOrder(@Valid OrderModel orderModel) throws UserNotFoundException, MovieNotFoundException {
		Users users = usersService.findByUserId(orderModel.getEmailId());
		Orders orders = new Orders();
		orders.setUsers(users);
		orders.setPurchaseDate(LocalDate.now());
		orders.setStatus("Pending");
		List<Movie> mv = new ArrayList<>();
		for(String m : orderModel.getMovList()) {
			Movie movie = movieService.findByMovieId(m);
			mv.add(movie);
			orders.setMovieList(mv);
			orders.setTotalQuantity(orders.getTotalQuantity() + 1);
			orders.setTotalPrice(orders.getTotalPrice() + movie.getPrice());
		}
		orders = ordersRepository.save(orders);
		return orders;
	}
	
	@Override
	public List<Orders> findAllOrders() {
		log.info("START");
		List<Orders> AllOrders = ordersRepository.findAll();
		log.debug("All Movies: {}", AllOrders);
		log.info("END");
		return AllOrders;
	}
	
	@Override
	public List<Orders> findOrdersByUserId(String emailId) throws OrderNotFoundException, UserNotFoundException   {
		Users users = usersService.findByUserId(emailId);
		if(ordersRepository.findOrdersByUserId(emailId).isEmpty())
		{
			throw new OrderNotFoundException("Order not found....");
		}
		List<Orders> oList = ordersRepository.findOrdersByUserId(emailId);
		return oList;
	}

	
	@Transactional
	@Override
	public void deleteOrderById(int orderId) throws OrderNotFoundException {
		log.info("START");
		Orders odrt = ordersRepository.findById(orderId).orElse(null);
		if(odrt==null) {
			throw new OrderNotFoundException("Order not found....");
		}
		log.debug("successfully deleted order");
		ordersRepository.deleteById(orderId);
		log.info("END");
	}
	
	@Transactional
	@Override
	public Orders FindOrderById(int orderId) throws OrderNotFoundException {
		log.info("START");
		Orders odrt = ordersRepository.findById(orderId).orElse(null);
		if(odrt==null) {
			throw new OrderNotFoundException("Order not found....");
		}
		log.debug("successfully fethched order");
		log.info("END");
		return odrt;
	}
	
	@Override
	public Orders approval(int orderId, boolean br) throws OrderNotFoundException {
		 Orders obj = ordersRepository.findbyorderId(orderId);
		 if(obj==null) {
			 throw new OrderNotFoundException("Order Not Found....");
		 }else {
			 if(br==true) {
		 obj.setStatus("Success");
			 }
			 else {
		 obj.setStatus("Canceled");
			 }
			 obj = ordersRepository.save(obj);
		return obj;
		 }
	}

}
