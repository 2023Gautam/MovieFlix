package com.cts.service;

import java.util.List;

import com.cts.exception.MovieNotFoundException;
import com.cts.model.Movie;

public interface MovieService {

	public Movie addMovie(Movie movie); //done
	public void deleteByMovieId(String movieId) throws MovieNotFoundException; //done
	public Movie findByMovieId(String movieId) throws MovieNotFoundException;
	public List<Movie> findBymovGenre(String movGenre) throws MovieNotFoundException; //done
	public List<Movie> findBymovTitle(String movTitle)throws MovieNotFoundException; //done
	public List<Movie> findAllMovies(); //done
	
}
