package com.cts.service;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.dao.MovieRepository;
import com.cts.exception.MovieNotFoundException;
import com.cts.model.Movie;

import jakarta.transaction.Transactional;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class MovieServiceImpl implements MovieService{
	
	@Autowired
	private MovieRepository repo;
	
	@Override
	@Transactional
	public Movie addMovie(Movie movie) {
		log.info("START");
		movie.setAvail(true);
		Movie save = repo.save(movie);
		log.debug("Movie Saved: {}", save);
		log.info("END");
		return save;
	}

	@Override
	public List<Movie> findAllMovies() {
		log.info("START");
		List<Movie> findAll = repo.findByAvail();
		log.debug("All Movies: {}", findAll);
		log.info("END");
		return findAll;
	}

	@Override
	@Transactional
	public void deleteByMovieId(String movieId) throws MovieNotFoundException {
		log.info("START");
		Movie movie = repo.findById(movieId).orElse(null);
		log.debug("Movie Found: {}", movie);
		if(movie==null) {
			log.error("Movie not found....");
			throw new MovieNotFoundException("Movie not found...");
		}
//		repo.deleteById(movieId);
		movie.setAvail(false);
		repo.save(movie);
		log.debug("Movie Deleted: {}", movie);
		log.info("END");
	}

	@Override
	public List<Movie> findBymovGenre(String movGenre) throws MovieNotFoundException {
		log.info("START");
		List<Movie> findBymovGenre = repo.findBymovGenre(movGenre);
		log.debug("Movie Found: {}", findBymovGenre);
		if(findBymovGenre.isEmpty()) {
			log.error("Movie Not Found...");
			throw new MovieNotFoundException("Movie not found...");
		}
		log.info("END");
		return findBymovGenre;
	}
	@Override
	public List<Movie> findBymovTitle(String movTitle) throws MovieNotFoundException {
		log.info("START");
		List<Movie> findBymovTitle = repo.findBymovTitle(movTitle);
		log.debug("Movie Found: {}", findBymovTitle);
		if(findBymovTitle.isEmpty()) {
			log.error("Movie Not Found...");
			throw new MovieNotFoundException("Movie not found...");
		}
		log.info("END");
		return findBymovTitle;
		
	}
	
	@Override
	public Movie findByMovieId(String movieId) throws MovieNotFoundException {
		log.info("START");
		System.out.println(movieId);
		Movie movie = repo.findById(movieId).orElse(null);
		System.out.println(movie);
		log.debug("Movie Found: {}", movie);
		if(movie==null) {
			log.error("Movie Not Found...");
			throw new MovieNotFoundException("Movie not found...");
		}
		log.info("END");
		 return movie;
	}



}
