package com.cts.service;

import org.springframework.stereotype.Service;

//import com.cts.exception.InvalidException;
import com.cts.exception.UserNotFoundException;
import com.cts.model.Users;
import com.cts.pojo.UsersModel;

@Service
public interface UsersService {
	
//	public Users addCust(CustomerModel cModel);
	public Users findByUserId(String emailId) throws UserNotFoundException;
	public Users customerLogin(String emailId, String password) throws UserNotFoundException;
	public Users adminsLogin(String emailId, String password) throws UserNotFoundException;
	Users addCust(UsersModel cModel) throws UserNotFoundException;
	
	
	

}
