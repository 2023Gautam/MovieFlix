package com.cts.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.dao.UsersRepository;
//import com.cts.exception.InvalidException;
import com.cts.exception.UserNotFoundException;
import com.cts.model.Users;
import com.cts.pojo.UsersModel;
//import com.cts.validator.UsersValidator;

import jakarta.transaction.Transactional;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class UsersServiceImpl implements UsersService{
	
	@Autowired
	private UsersRepository usersRepo;

	
	@Override
	@Transactional
	public Users addCust(UsersModel cModel) throws UserNotFoundException {
		log.info("START");
			Users u = usersRepo.findById(cModel.getEmailId()).orElse(null);
			if(u!=null) {
				throw new UserNotFoundException("Email Already Exists...");
			}
			Users users = new Users();
			users.setEmailId(cModel.getEmailId());
			users.setUserName(cModel.getUserName());
			users.setPassword(cModel.getPassword());
			users.setCatagory("cust");
			Users save = usersRepo.save(users);
			log.debug("Added User: {}", save);
			log.info("END");
			return save;
	}
 
	@Override
	public Users findByUserId(String emailId) throws UserNotFoundException{
		log.info("START");
		Users users = usersRepo.findById(emailId).orElse(null);
		if(users==null) {
			log.error("User Not Found...");
			throw new UserNotFoundException("User Not Found....");
		}
		log.debug("Found User: {}", users);
		log.info("END");
		return users;
	}

	@Override
	public Users customerLogin(String emailId, String password) throws UserNotFoundException {
		log.info("START");
		Users users = usersRepo.UserLogin(emailId, password);
		if(users==null) {
			log.error("Customer Not Found...");
			throw new UserNotFoundException("Customer Not Found....");
		}
		log.debug("Found Customer: {}", users);
		log.info("END");
		return users;
	}

	@Override
	public Users adminsLogin(String emailId, String password) throws UserNotFoundException {
		log.info("START");
		Users users = usersRepo.adminsLogin(emailId, password);
		if(users==null) {
			log.error("Admin Not Found...");
			throw new UserNotFoundException("Admin Not Found....");
		}
		log.debug("Found Admin: {}", users);
		log.info("END");
		return users;
	}
}
	
	
	
	
	
