import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AboutComponent } from './about/about.component';
import { AddMovieComponent } from './add-movie/add-movie.component';
import { AuthGuardService } from './auth-guard.service';
import { EditComponentComponent } from './edit-component/edit-component.component';
import { LogoutComponent } from './logout/logout.component';
import { MovieCartComponent } from './movie-cart/movie-cart.component';
import { UserHomeComponent } from './user-home/user-home.component';
import { UserRegisterComponent } from './user-register/user-register.component';
import { UserloginComponent } from './userlogin/userlogin.component';
import { ViewItemsComponent } from './view-items/view-items.component';
import { PaymentComponent } from './payment/payment.component';
import { ViewOrdersComponent } from './view-orders/view-orders.component';
import { BackgroundComponent } from './background/background.component';

const routes: Routes = [
  {path:'view' , component: ViewItemsComponent,},
  {path:'about' , component: AboutComponent},
  {path:'ulogin', component: UserloginComponent},
  {path:'uRegister', component: UserRegisterComponent},
  {path:'uHome', component: UserHomeComponent},
  {path: 'addMovie', component: AddMovieComponent, canActivate:[AuthGuardService]},
  {path: 'editMovie/:movId', component: EditComponentComponent, canActivate:[AuthGuardService]},
  {path:'logout', component: LogoutComponent, canActivate:[AuthGuardService]},
  {path:'movCart', component: MovieCartComponent, canActivate:[AuthGuardService]},
  {path:'payMent/:orderId', component: PaymentComponent, canActivate:[AuthGuardService]},
  {path:'viewOrders', component: ViewOrdersComponent, canActivate:[AuthGuardService]},
  {path:'background', component: BackgroundComponent, canActivate:[AuthGuardService]},
  {path: '', redirectTo: 'uHome', pathMatch: 'full'}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
