import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import Swal from 'sweetalert2';
import { DemoServiceService } from '../demo-service.service';
import { Movie } from '../movie';

// const express = require('express');
// const cors = require('cors');
// const app = express();

@Component({
  selector: 'app-edit-component',
  templateUrl: './edit-component.component.html',
  styleUrls: ['./edit-component.component.css']
})
export class EditComponentComponent {
  movId: any
  movie:Movie = new Movie()

  genreList=['Comedy','Action', 'Animation', 'Horror', 'Fiction', 'Romance', ]

  addForm = new FormGroup({
    // movId: new FormControl(this.movie.movId , Validators.required),
    movTitle: new FormControl(this.movie.movTitle, Validators.required),
    movGenre: new FormControl(this.movie.movGenre, Validators.required),
    movYear: new FormControl(this.movie.movYear, Validators.required),
    price: new FormControl(this.movie.price, Validators.required),
})
  
  constructor(private service: DemoServiceService, private router: Router, private route: ActivatedRoute){}

  ngOnInit(): void{
      this.movId = this.route.snapshot.paramMap.get('movId')
      this.service.getMovieById(this.movId).subscribe( data => {
        this.movie = data
        console.log(data)
        this.addForm = new FormGroup({
          movTitle: new FormControl(this.movie.movTitle, Validators.required),
          movGenre: new FormControl(this.movie.movGenre, Validators.required),
          movYear: new FormControl(this.movie.movYear,[Validators.required,Validators.min(1),Validators.pattern('^[0-9]{4}$')]),
          price: new FormControl(this.movie.price,[Validators.required,Validators.min(1),Validators.pattern('^[0-9]*$')]),
      })
  });
  }

  onSubmit(){
    Swal.fire({
      position: 'top-end',
      icon: 'success',
      title: 'Movie Edited Successfully!',
      showConfirmButton: false,
      background:'#212529',
      color: '#ffa31a',
      timer: 2500
    })
    let  movie:Movie = new Movie()
    movie.movId= this.movId
    movie.movTitle=this.addForm.value.movTitle
    movie.movGenre=this.addForm.value.movGenre
    movie.movYear=this.addForm.value.movYear
    movie.price=this.addForm.value.price
  this.service.addMovie(movie)
  .subscribe( data => {
    console.log(data)
    this.router.navigate(['view']);
  });
}  

}
