import { Approval } from './approval';

describe('Approval', () => {
  it('should create an instance', () => {
    expect(new Approval()).toBeTruthy();
  });
});
