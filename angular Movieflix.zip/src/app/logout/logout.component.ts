import { Component } from '@angular/core';
import { Router } from '@angular/router';
import Swal from 'sweetalert2';
import { DemoServiceService } from '../demo-service.service';

@Component({
  selector: 'app-logout',
  templateUrl: './logout.component.html',
  styleUrls: ['./logout.component.css']
})
export class LogoutComponent {

  constructor(private router: Router){}

  ngOnInit(){
    Swal.fire({
      title: 'Log-Out?',
      text: "Are You Sure?",
      icon: 'info',
      showCancelButton: true,
      background:'#212529',
      color: '#ffa31a',
      confirmButtonColor: '#ffa31a',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes, Log-out!'
    }).then((result) => {
      if (result.isConfirmed) {
    sessionStorage.removeItem("emailId");
    sessionStorage.removeItem("catagory");
    localStorage.removeItem("Cart");
    console.log("works logout");
    this.router.navigate(['about']);
  }else{
    this.router.navigate(['view']);
  }
})
  }
}
