export class Order {
    public emailId: any=''
    public movList: any=[]
}
