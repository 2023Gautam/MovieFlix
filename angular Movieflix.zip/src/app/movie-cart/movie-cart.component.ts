import { Component } from '@angular/core';
import { Router } from '@angular/router';
import Swal from 'sweetalert2';
import { DemoServiceService } from '../demo-service.service';

@Component({
  selector: 'app-movie-cart',
  templateUrl: './movie-cart.component.html',
  styleUrls: ['./movie-cart.component.css']
})
export class MovieCartComponent {
  cart:any=[];
  movList:any=[];
  constructor(private service: DemoServiceService, private router: Router){}

  ngOnInit(){
    this.cart=localStorage.getItem("Cart")?.split(",")
    // this.cart=this.cart.removeItem(this.cart.length-1);
    console.log(this.cart)
    for(let i=0;i<this.cart.length-1;i++){
      let movId = this.cart[i];
      console.log(movId);
      this.service.getMovieById(movId).subscribe( result=>{
        let movie = result;
        this.movList.push(movie);
      });
    }
  }

  back(){
    this.router.navigate(['view']);
  }

  deleteMovie(movId: any){
    Swal.fire({
      position: 'top-end',
      icon: 'success',
      width: '200px',
      title:  'Removed from cart',
      showConfirmButton: false,
      background:'#212529',
      color: '#ffa31a',
      timer: 800
    })
    this.cart=localStorage.getItem("Cart")?.split(",")
    const index = this.cart.indexOf(movId);
      if (index !== -1) {
        this.cart.splice(index, 1);
      }
    localStorage.setItem("Cart", this.cart)
      this.movList=[]
      this.ngOnInit();
}
}
