import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Approval } from './approval';
import { Customer } from './customer';
import { Movie } from './movie';
import { Order } from './order';


@Injectable({
  providedIn: 'root'
})
export class DemoServiceService {

  constructor(private http:HttpClient) { }

  getMovies(): Observable<any>{
    return this.http.get('http://localhost:8080/api/movies/showAll');
  }

  getMovieByGenre(Genre: any): Observable<any>{
    return this.http.get('http://localhost:8080/api/movies/SearchByGenre/'+ Genre);
  }

  getMovieByTitle(title: any): Observable<any>{
    return this.http.get('http://localhost:8080/api/movies/SearchByTitle/'+ title);
  }

  addMovie(movie: Movie): Observable<any>{
    return this.http.post('http://localhost:8080/api/movies/AddNew', movie);
  }

  deleteMovie(movId: any): Observable<any>{
    return this.http.delete('http://localhost:8080/api/movies/DeleteById/'+ movId);
  }

  getMovieById(movId: any): Observable<any>{
    return this.http.get('http://localhost:8080/api/movies/findById/'+ movId);
  }

  getUserDetails(emailId: any): Observable<any>{
    return this.http.get('http://localhost:8080/api/users/'+ emailId);
  }

  placeOrder(order: Order): Observable<any>{
    return this.http.post('http://localhost:8080/api/orders/placeOrder', order);
  }

  isLoggedUser():boolean{
    let emailId = sessionStorage.getItem("emailId");
    if(emailId!=null)
      return true;
    else
      return false;
  }

  getOrderById(orderId: any): Observable<any>{
    return this.http.get('http://localhost:8080/api/orders/findOrderByOrderId/'+ orderId);
  }

  getOrdersAll(): Observable<any>{
    return this.http.get('http://localhost:8080/api/orders/showAllOrders');
  }

  getOrderByUserId(userId: any): Observable<any>{
    return this.http.get('http://localhost:8080/api/orders/findOrderByUserId/'+ userId);
  }

  deleteOrderById(orderId: any): Observable<any>{
    return this.http.delete('http://localhost:8080/api/orders/deleteOrder/'+ orderId);
  }

  paymentApprovel(approval: Approval){
    return this.http.put('http://localhost:8080/api/orders/approval', approval);
  }

  isLoggedCust():boolean{
    let emailId = sessionStorage.getItem("emailId");
    let catagory = sessionStorage.getItem("catagory")
    if(emailId!=null && catagory=='cust')
      return true;
    else
      return false;
  }

  isLoggedAdm():boolean{
    let emailId = sessionStorage.getItem("emailId");
    let catagory = sessionStorage.getItem("catagory");
    if(emailId!=null && catagory=='adm')
      return true;
    else
      return false;
  }
  getEmail():any{
    let emailId = sessionStorage.getItem("emailId");
      return emailId;
  }

  addNewCustomer(customer: Customer): Observable<any>{
    return this.http.post('http://localhost:8080/api/users/customer', customer);
  }

  custLogin(obj: any): Observable<any>{
    return this.http.post('http://localhost:8080/api/users/userLogin', obj);
  }

  adminLogin(obj: any): Observable<any>{
    return this.http.post('http://localhost:8080/api/users/adminLogin', obj);
  }
}
