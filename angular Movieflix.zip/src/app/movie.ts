export class Movie {
public movId: any=''
public movTitle: any=''
public movGenre: any=''
public movYear: any=0
public price: any=0
}
