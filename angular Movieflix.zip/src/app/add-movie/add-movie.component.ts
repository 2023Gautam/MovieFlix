import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { DemoServiceService } from '../demo-service.service';
import {FormGroup, FormControl, Validators} from '@angular/forms'
import { Movie } from '../movie';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-add-movie',
  templateUrl: './add-movie.component.html',
  styleUrls: ['./add-movie.component.css']
})
export class AddMovieComponent {

  constructor(private service: DemoServiceService, private router: Router){}

  genreList=['Comedy','Action', 'Animation', 'Horror', 'Fiction', 'Romance', ]

  addForm = new FormGroup({
    movId: new FormControl('' , [Validators.required,Validators.pattern('^[A-Z]{2}[0-9]{3}$')]),
    movTitle: new FormControl('', Validators.required),
    movGenre: new FormControl('', Validators.required),
    movYear: new FormControl(0, [Validators.required,Validators.min(1),Validators.pattern('^[0-9]{4}$')]),
    price: new FormControl(0, [Validators.required,Validators.min(1),Validators.pattern('^[0-9]*$')]),
})

  onSubmit(){
    Swal.fire({
      position: 'top-end',
      icon: 'success',
      title: 'New Movie has Been Added!',
      showConfirmButton: false,
      background:'#212529',
      color: '#ffa31a',
      timer: 2500
    })
    let  movie:Movie = new Movie()
    movie.movId= this.addForm.value.movId
    movie.movTitle=this.addForm.value.movTitle
    movie.movGenre=this.addForm.value.movGenre
    movie.movYear=this.addForm.value.movYear
    movie.price=this.addForm.value.price
  this.service.addMovie(movie)
  .subscribe( data => {
    console.log(data)
    this.router.navigate(['view']);
  });
}  

}
