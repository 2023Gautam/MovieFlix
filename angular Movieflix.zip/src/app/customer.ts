export class Customer {
    public emailId: any=''
    public userName: any=''
    public password: any=''
}
