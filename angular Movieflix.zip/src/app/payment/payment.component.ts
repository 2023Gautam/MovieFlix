import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import Swal from 'sweetalert2';
import { Approval } from '../approval';
import { DemoServiceService } from '../demo-service.service';

@Component({
  selector: 'app-payment',
  templateUrl: './payment.component.html',
  styleUrls: ['./payment.component.css']
})
export class PaymentComponent {

  orderId:any=[]
  status:any=''
  totalPrice:any=''
  MovList:any=''
  TotalPrice:any=''



  addForm = new FormGroup({
    cardHolderName: new FormControl('', [Validators.required,Validators.pattern('[A-Za-z\\s]+$')]),
    cardCVV: new FormControl('', [Validators.required,Validators.minLength(3),Validators.maxLength(3),Validators.pattern('^[0-9]*$')]),
    cardNumber: new FormControl('', [Validators.required,Validators.minLength(16),Validators.maxLength(16),Validators.pattern('^[0-9]*$')]),
})
  
  constructor(private service: DemoServiceService, private router: Router, private route: ActivatedRoute){}

  ngOnInit(): void{
      this.orderId = this.route.snapshot.paramMap.get('orderId')
      console.log(this.orderId)
      this.service.getOrderById(this.orderId).subscribe( result => {
        this.orderId=result.orderId
        this.status=result.status
        this.MovList=result.movieList
        this.TotalPrice=result.totalPrice
  });
  }

  onSubmit(){
    Swal.fire({
      title: 'Are you sure?',
      text: "Complete your Order Transaction",
      icon: 'info',
      showCancelButton: true,
      background:'#212529',
      color: '#ffa31a',
      confirmButtonColor: '#ffa31a',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes, Place-Order'
    }).then((result) => {
      if (result.isConfirmed) {
  let  approval:Approval = new Approval()
  approval.orderId=this.orderId
  approval.status=true
  this.service.paymentApprovel(approval)
  .subscribe( data => {
    this.router.navigate(['viewOrders']);
  });
}
})
  }


}
