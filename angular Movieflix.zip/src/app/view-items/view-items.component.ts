import { Component } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
// import { debounceTime, map, Observable } from 'rxjs';
import Swal from 'sweetalert2';
import { DemoServiceService } from '../demo-service.service';
import { Order } from '../order';

@Component({
  selector: 'app-view-items',
  templateUrl: './view-items.component.html',
  styleUrls: ['./view-items.component.css']
})
export class ViewItemsComponent {
  movies:any=[];
  cart:any=[];
  movList:any=[];
  arr:any=0;
  Genre:any='';
  Title:any='';
  selectedMovie:any='';
  movieNames:any=[];

  // orderId:any='';
  // count:any
  genreList=['All','Comedy','Action', 'Animation', 'Horror', 'Fiction', 'Romance', ]

  constructor(private service:DemoServiceService, private router: Router){  }

  genreForm = new FormGroup({
    movGenre: new FormControl(''),
})

titleForm = new FormGroup({
  movTitle: new FormControl(''),
})

byGenre(){
  this.Genre=this.genreForm.value.movGenre
  if(this.Genre=="All"){
    this.ngOnInit();
  }else{
this.service.getMovieByGenre(this.Genre)
.subscribe( result => {
  this.movies = result
},
error=>{
  Swal.fire({
    icon: 'error',
    title: 'Oops...',
    text: 'No Movies Available under that genre',
    background:'#212529',
        color: '#ffa31a',
  })
});
}
} 

byTitle(){
  this.Title=this.titleForm.value.movTitle
this.service.getMovieByTitle(this.Title)
.subscribe( result => {
  this.movies = result
},
error=>{
  Swal.fire({
    icon: 'error',
    title: 'Oops...',
    text: 'No Movies Available under that Title',
    background:'#212529',
        color: '#ffa31a',
  })
});
}

  ngOnInit(){
    let cart = localStorage.getItem("Cart")
    if(cart!=null){
      this.arr = cart.split(",").length - 1;
    }else{
      this.arr=0
    }
      this.service.getMovies().subscribe( result=>{
        this.movies = result
        console.log(this.movies)
        this.movieNames=[];
        for(let i=0;i<this.movies.length;i++){
          this.movieNames.push(this.movies[i].movTitle);
        }
      });
    }

    movCart(){
      this.router.navigate(['movCart'])
    }

    isSignIn(){
      this.router.navigate(['ulogin'])
    }

    addNewMovies(){
      this.router.navigate(['addMovie'])
    }

    editMovies(movId: any){
      this.router.navigate(['editMovie', movId])
    }

    deleteMovie(movId: any){
      Swal.fire({
        title: 'Are you sure?',
        text: "Romove Movie",
        icon: 'info',
        showCancelButton: true,
        background:'#212529',
        color: '#ffa31a',
        confirmButtonColor: '#ffa31a',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, Remove Movie'
      }).then((result) => {
        if (result.isConfirmed) {   
          this.service.deleteMovie(movId).subscribe( result=>{
            Swal.fire({
              icon: 'success',
              title: 'Removed',
              text: 'Movies Successfully Removed',
              background:'#212529',
              color: '#ffa31a',
            })
            this.ngOnInit();
           }); 
        }
      })
    }

    placeOrder(){
      Swal.fire({
        title: 'Are you sure?',
        text: "Confirm Your Order",
        icon: 'info',
        showCancelButton: true,
        background:'#212529',
        color: '#ffa31a',
        confirmButtonColor: '#ffa31a',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, Confirm Order'
      }).then((result) => {
        if (result.isConfirmed) {
          let order = new Order();
          let orderId: any=0
          this.cart = localStorage.getItem("Cart")?.split(",")
          for(let i=0;i<this.cart.length-1;i++){
            let movId = this.cart[i];
            this.movList.push(movId);
          }
          order.emailId=sessionStorage.getItem("emailId")
          order.movList=this.movList
          this.service.placeOrder(order).subscribe( result => {
            orderId=result.orderId
            Swal.fire({
              icon: 'success',
              title: 'Order Recorded',
              text: 'Recorded Successfully!',
              background:'#212529',
              color: '#ffa31a',
            })
            this.router.navigate(['payMent', orderId]);
          },
          error=>{
            Swal.fire({
              icon: 'error',
              title: 'Oops...',
              text: 'No Movies Selected..',
              background:'#212529',
        color: '#ffa31a',
            })
          });    
        }
      })
    }

    addToCart(movId: any){
      Swal.fire({
        position: 'top-end',
        icon: 'success',
        width: '200px',
        title:  'Add to cart',
        showConfirmButton: false,
        background:'#212529',
        color: '#ffa31a',
        timer: 1000
      })
      let cart = localStorage.getItem("Cart")
      cart=cart+movId+","
      this.arr = cart.split(",").length-1;
      localStorage.setItem("Cart", cart)
    }

    get isLoggedAdm()
    {
      return this.service.isLoggedAdm();
    }

    get isLoggedUser()
    {
      return this.service.isLoggedUser();
    }

    get isLoggedCust()
    {
      return this.service.isLoggedCust();
    }

}
