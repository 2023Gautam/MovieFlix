import { Component } from '@angular/core';
import { Router } from '@angular/router';
import Swal from 'sweetalert2';
import { Approval } from '../approval';
import { DemoServiceService } from '../demo-service.service';

@Component({
  selector: 'app-view-orders',
  templateUrl: './view-orders.component.html',
  styleUrls: ['./view-orders.component.css']
})
export class ViewOrdersComponent {
  emailId:any=''
  catagory:any=''
  orders:any=[]
  ostatus:any=[]

  constructor(public service:DemoServiceService, private router: Router){ }

  ngOnInit(){
    // let Tstatus: any=0
    this.emailId=sessionStorage.getItem("emailId")
    this.catagory=sessionStorage.getItem("catagory")
    if(this.catagory=="adm"){
      this.service.getOrdersAll().subscribe( result=>{
        this.orders=result
        console.log(this.orders);
      });
    }else{
    this.service.getOrderByUserId(this.emailId).subscribe( result=>{
      this.orders=result
    });
  }
  }

  moveTopayMent(orderId: any){
    this.router.navigate(['payMent', orderId]);
  }

  cancelOrder(orderId: any){
    Swal.fire({
      title: 'Are you sure?',
      text: "You won't be able to revert this!",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#ffa31a',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes, Remove Order!'
    }).then((result) => {
      if (result.isConfirmed) {
        let  approval:Approval = new Approval()
  approval.orderId=orderId
  approval.status=false
  this.service.paymentApprovel(approval)
  .subscribe( data => {
    Swal.fire({
      icon: 'success',
      title: 'Canceled',
      text: 'Order Canceled Successfully!',
      background:'#212529',
color: '#ffa31a',
    })
    this.ngOnInit();
  });
    }
    })
  }

  deleteOrder(orderId: any){
    Swal.fire({
      title: 'Are you sure?',
      text: "You won't be able to revert this!",
      icon: 'warning',
      showCancelButton: true,
      background:'#212529',
        color: '#ffa31a',
      confirmButtonColor: '#ffa31a',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes, Delete Order!'
    }).then((result) => {
      if (result.isConfirmed) {
        this.service.deleteOrderById(orderId)
        .subscribe( data => {  
          Swal.fire({
            icon: 'success',
            title: 'Deleted',
            text: 'Order Deleted Successfully!',
            background:'#212529',
      color: '#ffa31a',
          })
    this.ngOnInit();
  });
    }
    })
  }
  

  isStatusApproved(Tstatus: any)
    {
      if(Tstatus=="Pending"){
        return true;
      }else{
        return false;
      }
    }
}
