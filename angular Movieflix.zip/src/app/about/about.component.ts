import { Component } from '@angular/core';
import {FormGroup, FormControl, Validators} from '@angular/forms'
import { Router } from '@angular/router';
import Swal from 'sweetalert2';
import { DemoServiceService } from '../demo-service.service';

@Component({
  selector: 'app-about',
  templateUrl: './about.component.html',
  styleUrls: ['./about.component.css']
})
export class AboutComponent {
  uname:string = ''
  email:string = ''
  status:boolean = false

  constructor(private service: DemoServiceService, private router: Router){}

  loginForm = new FormGroup({
    emailId: new FormControl('',[Validators.required,Validators.email]),
    password: new FormControl('',[Validators.required,Validators.minLength(4),Validators.maxLength(4),Validators.pattern('^[0-9]*$')])
  })

  login(){
    let obj={
      "emailId": this.loginForm.value.emailId,
      "userName": "x",
      "password": this.loginForm.value.password
    }
      this.service.adminLogin(obj).subscribe( result=>{
        Swal.fire({
          icon: 'success',
          title: 'Congrats',
          text: result.status,
          background:'#212529',
        color: '#ffa31a',
        })
        this.service.getUserDetails(obj.emailId).subscribe( result=>{
          console.log(result)
          sessionStorage.setItem("emailId", result.emailId);
          sessionStorage.setItem("catagory", result.catagory);
          this.router.navigate(['view'])
        });
      },
      error=>{
        Swal.fire({
          icon: 'error',
          title: 'Oops...',
          text: 'Incorrect Credentials for Admin',
          background:'#212529',
        color: '#ffa31a',
        })
        this.router.navigate(['about'])
      });
    }

  get user()
  {
    return this.loginForm.get('emailId');
  }
  get password()
  {
    return this.loginForm.get('password');
  }
  get name()
  {
    return this.loginForm.get('name');
  }
}
