import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AboutComponent } from './about/about.component';
import {FormsModule} from '@angular/forms';
import { ViewItemsComponent } from './view-items/view-items.component'; 
import { HttpClientModule } from '@angular/common/http';
import {ReactiveFormsModule} from '@angular/forms';
import { UserloginComponent } from './userlogin/userlogin.component';
import { UserRegisterComponent } from './user-register/user-register.component';
import { UserHomeComponent } from './user-home/user-home.component';
import { AddMovieComponent } from './add-movie/add-movie.component';
import { EditComponentComponent } from './edit-component/edit-component.component';
import { NavBarComponent } from './nav-bar/nav-bar.component';
import { LogoutComponent } from './logout/logout.component';
import { MovieCartComponent } from './movie-cart/movie-cart.component';
import { PaymentComponent } from './payment/payment.component';
import { ViewOrdersComponent } from './view-orders/view-orders.component';
import { BackgroundComponent } from './background/background.component';
import { FooterComponent } from './footer/footer.component';
import { TypeaheadModule } from 'ngx-bootstrap/typeahead';

@NgModule({
  declarations: [
    AppComponent,
    AboutComponent,
    ViewItemsComponent,
    UserloginComponent,
    UserRegisterComponent,
    UserHomeComponent,
    AddMovieComponent,
    EditComponentComponent,
    NavBarComponent,
    LogoutComponent,
    MovieCartComponent,
    PaymentComponent,
    ViewOrdersComponent,
    BackgroundComponent,
    FooterComponent
  ],
  
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule,
    TypeaheadModule.forRoot()
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
