export class Approval {
    public orderId : any=''
    public status : any=''
}
