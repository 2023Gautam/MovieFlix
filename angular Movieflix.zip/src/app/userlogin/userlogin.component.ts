import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import Swal from 'sweetalert2';
import { DemoServiceService } from '../demo-service.service';

@Component({
  selector: 'app-userlogin',
  templateUrl: './userlogin.component.html',
  styleUrls: ['./userlogin.component.css']
})
export class UserloginComponent {

  uname:any = ''
  email:string = ''
  status:boolean = false
  cart:any=''
  count:any=0;

  constructor(private service: DemoServiceService, private router: Router){}

  loginForm = new FormGroup({
    emailId: new FormControl('',[Validators.required,Validators.email]),
    password: new FormControl('',[Validators.required,Validators.minLength(4),Validators.pattern('^[0-9]*$')])
  })

  login(){
    // console.log(this.loginForm.value);
    // let x = this.loginForm.value;
    let obj={
      "emailId": this.loginForm.value.emailId,
      "userName": "x",
      "password": this.loginForm.value.password
    }
    console.log(obj.emailId)
    console.log(obj.password)
      this.service.custLogin(obj).subscribe( result=>{
        Swal.fire({
          icon: 'success',
          title: 'Congrats',
          text: result.status,
          background:'#212529',
        color: '#ffa31a',
        })
        this.service.getUserDetails(obj.emailId).subscribe( result=>{
          console.log(result)
          sessionStorage.setItem("emailId", result.emailId);
          sessionStorage.setItem("catagory", result.catagory);
          let c = localStorage.getItem("Cart")
          if(c==null){
             localStorage.setItem("Cart", this.cart)
          }else{
            localStorage.setItem("Cart", c) 
          }
          this.router.navigate(['view'])
        });
      },
      error=>{
        Swal.fire({
          icon: 'error',
          title: 'Oops...',
          text: 'Incorrect Credentials for Customer',
          background:'#212529',
        color: '#ffa31a',
        })
        this.router.navigate(['ulogin'])
      });
    }

  get emailId()
  {
    return this.loginForm.get('emailId');
  }

  get password()
  {
    return this.loginForm.get('password');
  }

}
