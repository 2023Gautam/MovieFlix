import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { DemoServiceService } from '../demo-service.service';

@Component({
  selector: 'app-nav-bar',
  templateUrl: './nav-bar.component.html',
  styleUrls: ['./nav-bar.component.css']
})
export class NavBarComponent {

  constructor(public service: DemoServiceService, private router: Router){
    this.uname = sessionStorage.getItem("emailId");
  }

  uname:any = ''

  ngOnInit(){
    this.uname = sessionStorage.getItem("emailId");
  }
  



}
