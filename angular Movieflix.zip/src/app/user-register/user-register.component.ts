import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import Swal from 'sweetalert2';
import { Customer } from '../customer';
import { DemoServiceService } from '../demo-service.service';

@Component({
  selector: 'app-user-register',
  templateUrl: './user-register.component.html',
  styleUrls: ['./user-register.component.css']
})
export class UserRegisterComponent {

  // emailId:any='';

  constructor(private service: DemoServiceService, private router: Router){}

  addForm = new FormGroup({
    emailId: new FormControl('',[Validators.required,Validators.email]),
    userName: new FormControl('',[Validators.required]),
    password: new FormControl('',[Validators.required,Validators.minLength(4),Validators.maxLength(4),Validators.pattern('^[0-9]*$')]),
})

Register(){
    let  customer:Customer = new Customer()
    customer.emailId= this.addForm.value.emailId
    customer.userName=this.addForm.value.userName
    customer.password=this.addForm.value.password

      this.service.addNewCustomer(customer)
      .subscribe( data => {
        Swal.fire('Congrats','You have Successfully Registered','success');
        this.router.navigate(['ulogin']);
      },
      error=>{
        Swal.fire({
          icon: 'error',
          title: 'Oops...',
          text: 'Customer Already Exists!..',
        })
        this.router.navigate(['uRegister']);
      }
      );
}

get emailId()
  {
    return this.addForm.get('emailId');
  }

  get password()
  {
    return this.addForm.get('password');
  }

  get name()
  {
    return this.addForm.get('username');
  }
}
